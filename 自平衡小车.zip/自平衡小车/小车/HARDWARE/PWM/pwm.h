#ifndef _PWM_H
#define _PWM_H
#include "sys.h"
#include "usart.h"
void PWM_Init_TIM14(u16 arr,u16 psc);
void PWM_Init_TIM3(u16 arr,u16 psc);
//TIM14->CCR1 = Compare1;
//  TIM14->CCR1 = Compare1;
#endif
