#ifndef  _MOTOR_H
#define  _MOTOR_H
#include "sys.h"
#include "usart.h"
void Motor12_Init(void);



#define R1 PDout(0)	
#define R2 PDout(2)	
#define L1 PDout(4)	
#define L2 PDout(6)	


void Xianfu_Pwm(void);
int abs(int p);

#endif



