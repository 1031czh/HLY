#include "usart3.h"
#include <string.h>

void UART3_Init(u32 bound) {
    GPIO_InitTypeDef GPIO_InitStruct;
    USART_InitTypeDef USART_InitStruct;
    NVIC_InitTypeDef NVIC_InitStruct;

    // 1. ????(F4?USART3??APB1,GPIOB?AHB1)
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);      // GPIOB??
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);     // USART3??

    // 2. ??PB10(USART3_TX)???????
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;                  // ????
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;                // ????
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;            // F4??100MHz
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;                  // ??(??)
    GPIO_Init(GPIOB, &GPIO_InitStruct);

    // 3. ??PB11(USART3_RX)???????
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_11;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;                  // ????
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;              // ????
    GPIO_Init(GPIOB, &GPIO_InitStruct);

    // 4. ?PB10/PB11???USART3(F4?????????)
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource10, GPIO_AF_USART3); // PB10 -> USART3_TX
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource11, GPIO_AF_USART3); // PB11 -> USART3_RX

    // 5. ???USART3
    USART_InitStruct.USART_BaudRate = bound;                   // ???
    USART_InitStruct.USART_WordLength = USART_WordLength_8b;   // 8???
    USART_InitStruct.USART_StopBits = USART_StopBits_1;        // 1????
    USART_InitStruct.USART_Parity = USART_Parity_No;           // ???
    USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None; // ???
    USART_InitStruct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx; // ????
    USART_Init(USART3, &USART_InitStruct);

    // 6. ??USART3????(??)
    USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);             // ??????

    // 7. ??NVIC(?????)
    NVIC_InitStruct.NVIC_IRQChannel = USART3_IRQn;
    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;      // ?????
    NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;             // ????
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStruct);

    // 8. ??USART3
    USART_Cmd(USART3, ENABLE);
}
/*
0x00:ɲ��
0x01:ǰ��
0x02:����
0x03:��ת
0x07:��ת
*/
u8 Fore,Back,Left,Right,Stop;
void USART3_IRQHandler(void)                	    // ����1�жϷ������
{
  int Bluetooth_data;
  if(USART_GetITStatus(USART3,USART_IT_RXNE)!=0)  // �����жϱ�־λ����
  {
    Bluetooth_data=USART_ReceiveData(USART3);     // ������յ���ָ��
    if(Bluetooth_data==0x00)Fore=0,Back=0,Left=0,Right=0,Stop=0; // ɲ��
    else if(Bluetooth_data==0x01)Fore=1,Back=0,Left=0,Right=0,Stop=0; // ǰ��
    else if(Bluetooth_data==0x05)Fore=0,Back=1,Left=0,Right=0,Stop=0; // ����
    else if(Bluetooth_data==0x03)Fore=0,Back=0,Left=1,Right=0,Stop=0; // ��ת
    else if(Bluetooth_data==0x07)Fore=0,Back=0,Left=0,Right=1,Stop=0; // ��ת
		else if(Bluetooth_data==0x09)Fore=0,Back=0,Left=0,Right=0,Stop=1;
    else                    Fore=0,Back=0,Left=0,Right=0,Stop=0;
  }
}

// ����һ��
void USART3_Send_Data(char data)
{
  USART_SendData(USART3,data);
  while(USART_GetFlagStatus(USART3,USART_FLAG_TC)==0);  // ���Ƿ������  
}

// ����һ��
void USART3_Send_String(char *String)
{
  u16 len,j;
  len=strlen(String);
  for(j=0;j<len;j++)
  {
    USART3_Send_Data(*String++);
  }
}

