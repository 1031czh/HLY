#ifndef  _EXTI_H
#define  _EXTI_H

#include "sys.h" 
#include "stm32f4xx.h"

void MPU6050_EXTI_Init(void);
#endif


