#ifndef __ENCODER_H
#define __ENCODER_H

#include "stm32f4xx.h"

// void Encoder_GPIO_Init(void);
// void Encoder_EXTI_Init(void);
// void Encoder_Get_Count(void);
void Encoder_RIGHT_Init(void);
void Encoder_LEFT_Init(void);
void Encoder_Reset(void);
void Encoder_GetCount(void);
//void Turn_timeFlag (void);


extern volatile uint8_t encoder_countFlag;
extern volatile int32_t count_right ;
extern volatile int32_t count_left ;
// extern volatile int16_t encoder_val;
 #endif


