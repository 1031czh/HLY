#include "ti_msp_dl_config.h"
#include <pwm.h>
#include "motor.h"
#include "servo.h"
#include "delay.h"
#include "huidu.h"
#include "pid.h"
#include "fmq.h"
#include "key.h"
#include "OLED.h"
#include <hw_encoder.h>

int main(void) 
{
    /* 初始化系统配置（包括GPIO和TIMG0） */
    SYSCFG_DL_init();

    servoInit();      // 启动舵机定时器
    // 初始化OLED
    NVIC_EnableIRQ(KEY_INT_IRQN);
    //清除定时器中断标志
    // NVIC_ClearPendingIRQ(TIMER_SUDU_INST_INT_IRQN);
    // //使能定时器中断
    NVIC_EnableIRQ(TIMER_SUDU_INST_INT_IRQN);
    OLED_Init();
    
    speedPIDInit();

    /* 启动PWM定时器 */
    DL_TimerG_startCounter(PWM_0_INST);
    DL_TimerG_startCounter(TIMER_SUDU_INST);
    /* 初始设置：前进，50%占空比 */
    setCarDirection(CAR_FORWARD);
    //setMotorSpeed(750, 750); // 左右轮速度相同
    //Beep_Time(300);
    //setServoAngle(-30);//向左转30度
   // 初始化PID变量
    // error = 0;
    // lastError = 0;
    // integral = 0;
    // derivative = 0;
    // pidOutput = 0;

     while(1)
      {
            // 计时逻辑
        if (!timeLocked) 
        {
            idleCounter++;
            if (idleCounter >= 5)
             {
                timeLocked = 1;  // 超过2秒未按键，锁定Time
            }
        }
        // OLED显示优化：区分锁定前后的Time显示
        OLED_ShowString(1, 1, "Time:");
        if (timeLocked)
        {
             uint8_t grayData = gray_8channel_read();  // 读取灰度传感器数据
             uint8_t blackLineCount = countBlackLines(grayData);  // 统计黑线检测数量
            // 显示锁定后的Time值，并标注"Locked"
            OLED_ShowNum(1, 6, Time, 2);  // 显示锁定值
            OLED_ShowString(1, 9, "Locked");         // 提示已锁定
            
            
            //     else 
            //    {
            //  // 正常循迹逻辑            
            // //  int8_t currentError = calculateError(grayData);  // 计算当前偏差
            // //  pidOutput = pidControl(currentError);     // 计算PID输出
            // //  setServoAngle((int16_t)pidOutput);        // 应用舵机角度
            // // controlServoByGray(grayData);
            // uint16_t motorPWM = speedPIDControl(speed);
            // setMotorSpeed(motorPWM, motorPWM);  // 应用计算后的PWM
            //    }
        }
        else
        {
            // 未锁定时显示实时Time值
            OLED_ShowNum(1, 6, Time, 2);
            OLED_ShowString(1, 9, "      ");  // 清空"Locked"提示（6个空格）
        }

        //    // 初始显示时间
        // OLED_ShowString(1, 1, "Time:");
        // OLED_ShowNum(1, 6, Time, 2);  // 第1行第6列显示2位数字
        // // OLED_ShowString(2, 1, "idleCounter:");
        // // OLED_ShowNum(2, 13, idleCounter, 3);
        // OLED_ShowString(2, 1, "speed:");
        // OLED_ShowNum(2, 7, speed, 2);
        //OLED_ShowString(2, 1, "speedIntegral:");
        //OLED_ShowNum(3, 1, speedIntegral, 4);
        OLED_ShowString(3, 1, "pwm:");
        OLED_ShowNum(3, 5, pwmOutput, 4);
        // 判断是否需要停止：超过2个传感器检测到黑线
         
        
         //delay_ms(10);  // 控制检测频率
    }
}