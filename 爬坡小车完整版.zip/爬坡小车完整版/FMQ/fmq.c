#include "ti_msp_dl_config.h"
#include "fmq.h"
#include "delay.h"

 void Beep_On(void)
 {
   DL_GPIO_setPins(FengMing_PORT, FengMing_PIN_0_PIN);
 }

void Beep_Off(void)
{
  DL_GPIO_clearPins(FengMing_PORT, FengMing_PIN_0_PIN);
}

void Beep_Time(uint32_t ms)
{
    Beep_On();
    delay_ms(500);  
    Beep_Off();
}
