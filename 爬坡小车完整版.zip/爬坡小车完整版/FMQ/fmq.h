#include "ti_msp_dl_config.h"

void Beep_On(void);
void Beep_Off(void);
void Beep_Time(uint32_t ms);
