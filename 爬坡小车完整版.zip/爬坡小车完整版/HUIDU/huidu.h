#ifndef __HUIDU_H__
#define __HUIDU_H__
#include "ti_msp_dl_config.h"
#include "stdio.h"
#define GPIO_PIN_SET   1
#define GPIO_PIN_RESET 0
#define BLACK_LINE_THRESHOLD 5 //检测黑线的条数阈值
// 读取八路灰度传感器数据（返回8位数据，每一位对应一个通道的黑白状态）
// bit0~bit7分别对应1~8通道，1表示黑线，0表示白线（根据传感器实际定义调整）
uint8_t gray_8channel_read(void);
uint8_t countBlackLines(uint8_t grayData);
#endif