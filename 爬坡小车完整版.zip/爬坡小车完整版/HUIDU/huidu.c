#include "ti_msp_dl_config.h"
#include "huidu.h"
#include "delay.h"  // 


uint8_t gray_8channel_read(void) {
    uint8_t data = 0;
    for (int i = 0; i < 8; i++) {
        DL_GPIO_clearPins(huidu_PORT, huidu_CLK_PIN);
        delay_us(5);
        data |= (!DL_GPIO_readPins(huidu_PORT, huidu_DAT_PIN)) << i; 
        DL_GPIO_setPins(huidu_PORT, huidu_CLK_PIN);
        delay_us(5);
    }
    return data;
}

// 统计检测到黑线的传感器数量
uint8_t countBlackLines(uint8_t grayData) {
    uint8_t count = 0;
    // 遍历8个传感器通道，统计置位（检测到黑线）的数量
    for (uint8_t i = 0; i < 8; i++) {
        if (grayData & (1 << i)) {  // 若第i位为1，表示检测到黑线
            count++;
        }
    }
    return count;
}