#include "ti_msp_dl_config.h"

void setMotorSpeed(uint16_t leftSpeed, uint16_t rightSpeed);