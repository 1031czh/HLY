#include "ti_msp_dl_config.h"

/* 设置PWM占空比（0-1000对应0%-100%，与配置的period匹配） */
void setMotorSpeed(uint16_t leftSpeed, uint16_t rightSpeed)
 {
    DL_TimerG_setCaptureCompareValue(PWM_0_INST, leftSpeed,  DL_TIMER_CC_0_INDEX);
    DL_TimerG_setCaptureCompareValue(PWM_0_INST, rightSpeed, DL_TIMER_CC_1_INDEX);
}

