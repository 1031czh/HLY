#include "ti_msp_dl_config.h"
#include "key.h"
#include "delay.h"
#include "fmq.h"
#include "OLED.h"
#include "pid.h"
#include "huidu.h"
#include "servo.h"

uint32_t Time = 10;
uint8_t timeLocked = 0;
uint16_t idleCounter = 0;  // 空闲计数器
int count = 0;
int16_t count_last=0;
float_t speed;
uint8_t pidMode = 0;  // 初始化PID模式为pid1

#define GPIO_MULTIPLE_GPIOA_INT_IIDX DL_INTERRUPT_GROUP1_GPIOA


void GROUP1_IRQHandler(void)
{
    switch (DL_Interrupt_getPendingGroup(DL_INTERRUPT_GROUP_1)) {
        #if defined GPIO_MULTIPLE_GPIOA_INT_IIDX
        case GPIO_MULTIPLE_GPIOA_INT_IIDX:
            switch (DL_GPIO_getPendingInterrupt(GPIOA))
            {       
                case KEY_PIN_18_IIDX:
                if (!timeLocked)
                { 
                    Time++; // Time加一
                    Beep_Time(500);
                     delay_ms(20); // 简单去抖
                    idleCounter = 0; // 按键后重置计数器
                }           
                    DL_GPIO_clearInterruptStatus(GPIOA, KEY_PIN_18_PIN);
                    break;

                case KEY_PIN_17_IIDX:
                    if (!timeLocked)
                    {
                        
                      //  Beep_Time(500); 
                      //  delay_ms(20); // 去抖
                        pidMode = !pidMode;  // 根据模式更新PID参数
                                if (pidMode == 1)
                                {
                                    // 切换到pid2参数
                                    SPEED_KP = SPEED_KP2;
                                    SPEED_KI = SPEED_KI2;
                                    SPEED_KD = SPEED_KD2;
                                    BASE_SPEED_PWM=BASE_SPEED_PWM2;
                                    Beep_Time(300); // 短鸣提示切换成功
                                    //OLED_ShowString(2, 2, "PID2:");
                                }
                                else
                                {
                                    // 切换回pid1参数
                                    SPEED_KP = 10.0f;
                                    SPEED_KI = 0.0f;
                                    SPEED_KD = 0.0f;
                                    BASE_SPEED_PWM=620;
                                    Beep_Time(500); // 长鸣提示切换回原参数
                                    OLED_ShowString(2, 2, "PID1:");
                                }
                     }
                    DL_GPIO_clearInterruptStatus(GPIOA, KEY_PIN_17_PIN);
                    break;

                 default:
               
                    break;
             }
             
              #endif    
    }
    

    if (DL_GPIO_getEnabledInterruptStatus(GPIOB, DL_GPIO_PIN_0) == DL_GPIO_PIN_0) 
     {  //判断B0是否产生中断
        if(DL_GPIO_readPins(GPIOB, DL_GPIO_PIN_0) == 0)  //读取B0状态
        {
            count--;
        }
        else {
            count++;
        }
         DL_GPIO_clearInterruptStatus(GPIOB, DL_GPIO_PIN_0); //清除B0中断标志
    }    
   
    if( DL_TimerA_getPendingInterrupt(TIMER_TICK_INST) == DL_TIMER_IIDX_ZERO )
    {
           speed=((count-count_last)*7.85)/(390*0.01);
         count_last =count;
    }

}

