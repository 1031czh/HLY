#include "ti_msp_dl_config.h"


void GROUP1_IRQHandler(void);
// 时间变量
 extern uint32_t Time;
 extern uint8_t timeLocked;
extern uint16_t idleCounter ;  // 空闲计数器;
extern int count;
extern float_t speed;
extern uint8_t pidMode;