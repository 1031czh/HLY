#include "ti_msp_dl_config.h"

//-------------------------舵机----------------------
// 声明PID控制变量（供其他文件使用）
extern float error;         // 当前误差
extern float lastError;     // 上一次误差
extern float integral;      // 积分项
extern float derivative;    // 微分项
extern float pidOutput;     // PID输出

int8_t calculateError(uint8_t grayData);
float pidControl(int8_t targetError);
// void controlServoByGray(uint8_t grayData);

//-----------------------------速度-------------------
extern float targetSpeed;    // 目标速度
extern float speedError;     // 速度误差
extern float speedIntegral;  // 速度积分项
extern float speedDerivative;// 速度微分项

extern float SPEED_KP;
extern float SPEED_KI;
extern float SPEED_KD;
extern float BASE_SPEED_PWM;
extern uint16_t pwmOutput; 

#define SPEED_KP2   8.0f
#define SPEED_KI2   10.05f
#define SPEED_KD2   0.0f
#define BASE_SPEED_PWM2  620   // 基础速度PWM

void speedPIDInit(void);
uint16_t speedPIDControl(float currentSpeed);