#include "ti_msp_dl_config.h"
#include "pid.h"
#include <key.h>
#include "huidu.h"
#include "servo.h"
#include "pwm.h"
#include "fmq.h"
//-------------------------------------灰度pid---------------------------------
// 舵机角度范围
#define SERVO_MAX_ANGLE  50
#define SERVO_MIN_ANGLE -50

// PID参数（需根据实际调试调整）
#define KP  40.0f   // 比例系数   32.0
#define KI  0.001f  // 积分系数
#define KD  15.0f   // 微分系数

// 灰度传感器通道对应的偏差值
// 中间通道(4,5)偏差为0，左侧通道偏差为正，右侧为负
const int8_t channelError[] = {-3, -2, -1, 0, 0, 1, 2, 3};

// PID控制变量
float error = 0;         // 当前误差
float lastError = 0;     // 上一次误差
float integral = 0;      // 积分项
float derivative = 0;    // 微分项
float pidOutput = 0;     // PID输出

// 计算偏差值

int8_t calculateError(uint8_t grayData) {
    int8_t currentError = 0;
    uint8_t channelCount = 0;
    
    // 遍历所有8个通道，计算平均偏差
    for (uint8_t i = 0; i < 8; i++) {
        if (grayData & (1 << i)) {
            currentError += channelError[i];
            channelCount++;
        }
    }
    
    // 如果没有检测到黑线，保持上一次偏差（防止突然失控）
    return (channelCount > 0) ? (currentError / channelCount) : lastError;
}

// PID控制计算
float pidControl(int8_t targetError)
 {
    lastError = error;
    error = targetError;
    
    // 积分项（限制积分范围，防止饱和）
    integral += error;
    if (integral > 50)  integral = 50;
    if (integral < -50) integral = -50;
    
    // 微分项
    derivative = error - lastError;
    
    // PID计算
    pidOutput = KP * error + KI * integral + KD * derivative;
    
    // 限制输出范围
    if (pidOutput > SERVO_MAX_ANGLE)
        pidOutput = SERVO_MAX_ANGLE;
    if (pidOutput < SERVO_MIN_ANGLE)
        pidOutput = SERVO_MIN_ANGLE;
    
    return pidOutput;
}
// const int16_t CHANNEL_ANGLE_MAP[8] = {-65,-45,-25,0,0,25,45,65 };
// static int16_t lastValidAngle = 0;

// void controlServoByGray(uint8_t grayData)
//  {
//     int16_t targetAngle = lastValidAngle;       // 默认角度（中间）
//     int8_t detectedChannel = -1;  // 检测到黑线的通道（初始为无效）
//     uint8_t hasBlackLine = 0;


//     // 遍历8个通道，查找第一个检测到黑线的通道（bit为1表示黑线）
//     for (uint8_t i = 0; i < 8; i++) {
//         if (grayData & (1 << i)) {
//             detectedChannel = i;
//             hasBlackLine = 1;
//             break;  // 只处理第一个检测到的通道
//         }
//     }

//     // 根据检测到的通道设置目标角度
//     if (detectedChannel != -1) {
//         targetAngle = CHANNEL_ANGLE_MAP[detectedChannel];
//     }
//    if (hasBlackLine) 
//    {
//         targetAngle = CHANNEL_ANGLE_MAP[detectedChannel];
//         lastValidAngle = targetAngle;  // 保存当前有效角度
//     }
//     输出舵机角度（内部已做角度限制）
//     setServoAngle(targetAngle);
// }

void TIMER_SUDU_INST_IRQHandler(void)
{
      //如果产生了定时器中断
    switch( DL_TimerG_getPendingInterrupt(TIMER_SUDU_INST) )
    {
        case DL_TIMER_IIDX_ZERO://如果是0溢出中断
            {
                 if (timeLocked)
                 {
            uint8_t grayData = gray_8channel_read();  // 读取灰度传感器数据
             uint8_t blackLineCount = countBlackLines(grayData);  // 统计黑线检测数量
            int8_t currentError = calculateError(grayData);  // 计算当前偏差
             pidOutput = pidControl(currentError);     // 计算PID输出
             setServoAngle((int16_t)pidOutput);        // 应用舵机角度
            uint16_t motorPWM = speedPIDControl(speed);
            setMotorSpeed(motorPWM, motorPWM);  // 应用计算后的PWM
            DL_Timer_clearInterruptStatus(TIMER_SUDU_INST, DL_TIMER_IIDX_ZERO);
            if (blackLineCount > BLACK_LINE_THRESHOLD)
             {
             setMotorSpeed(0, 0);  // 停止电机
             Beep_Time(100);
            }
            break;
            }
            }
        default://其他的定时器中断
            break;
    }
 }

//-------------------------------速度环pid--------------------------------------------------
float SPEED_KP=10.0f;
float SPEED_KI=0.0f;
float SPEED_KD=0.0f;
float BASE_SPEED_PWM=620;
uint16_t pwmOutput; 
// 速度限制范围

#define SPEED_DELTA_MAX 160  // 最大调节增量
 
// 速度PID全局变量
float targetSpeed = 0.0f;    // 目标速度
float speedError = 0.0f;     // 当前误差
float lastSpeedError = 0.0f; // 上一次误差
float speedIntegral = 0.0f;  // 积分项
float speedDerivative = 0.0f;// 微分项


void speedPIDInit (void)
 {
    targetSpeed = 0.0f;
    speedError = 0.0f;
    lastSpeedError = 0.0f;
    speedIntegral = 0.0f;
    speedDerivative = 0.0f;

}

uint16_t speedPIDControl(float currentSpeed)
 {
    // 计算目标速度：锁定后的Time除以44
    if (timeLocked)
     { 
        if(pidMode == 1)
        {   
            if (18<(float)Time<21) 
            {
              targetSpeed = 49.0f / (float)Time;
            }
            else {
            targetSpeed = 43.0f / (float)Time;
            }
            
        }
       else
        {
            if(15<(float)Time<19)
          {
            targetSpeed = 83.0f / (float)Time;
            }
          else
             {
            targetSpeed = 74.0f / (float)Time;
            }
       }

    } else {
        // 未锁定时目标速度设为0或初始值
        targetSpeed = 0.0f;
    }
     
     
    // 计算速度误差
    lastSpeedError = speedError;
    speedError = targetSpeed - currentSpeed;

    // 积分项（限制积分范围，防止饱和）
    speedIntegral += speedError;
    if (speedIntegral > 50) 
    {
        speedIntegral = 50;
    } 
    else if (speedIntegral < -50)
     {
        speedIntegral = -50;
    }
   
    // 微分项
    speedDerivative = speedError - lastSpeedError;

    // 5. PID计算
    float pwmDelta = SPEED_KP * speedError +  SPEED_KI * speedIntegral + SPEED_KD * speedDerivative;

    // 6. 总输出 = 基础速度 + 调节增量，限制范围
    pwmOutput = (uint16_t)(BASE_SPEED_PWM + pwmDelta);
    // 限制在基础速度±最大调节量范围内    
    if (pidMode == 1)
     {
        if (pwmOutput > BASE_SPEED_PWM2 + SPEED_DELTA_MAX)
             pwmOutput = BASE_SPEED_PWM2 + SPEED_DELTA_MAX;
                 else if (pwmOutput < BASE_SPEED_PWM2-SPEED_DELTA_MAX)
                        pwmOutput = BASE_SPEED_PWM2-SPEED_DELTA_MAX ;
        //pwmOutput -= 50;  // 当pidMode为1时减去100
    }
    
    else
    {
         
         if (pwmOutput > BASE_SPEED_PWM + SPEED_DELTA_MAX)
            pwmOutput = BASE_SPEED_PWM + SPEED_DELTA_MAX;
               else if (pwmOutput < BASE_SPEED_PWM)
                       pwmOutput = BASE_SPEED_PWM ;
    }
  
//    if (pidMode == 0)
//     {
//     if(15<(float)Time<19)
//     {
//       pwmOutput -= 5;
//     }
    }
    if (pidMode == 1)
    {
    if(15<(float)Time<18)
    {
      pwmOutput += 5;
    }
       else if (17<(float)Time<19)
        {
         pwmOutput += 30;
       }
        
    }
    return (uint16_t)pwmOutput;
 }
