#include "ti_msp_dl_config.h"
#include "servo.h"

#define SERVO_CENTER_PULSE 1600  // 中间位置(90度)对应的比较值，作为0度参考点
#define SERVO_MIN_PULSE    500   // 最左位置(-90度)对应的比较值
#define SERVO_MAX_PULSE    2500  // 最右位置(+90度)对应的比较值

void servoInit(void)
{
    // 启动TIMG12定时器
    DL_TimerG_startCounter(PWM_SERVO_INST);
}

void setServoAngle(int16_t angle) 
{
    uint32_t pulse;

    // 限制角度范围在-90到+90之间
    if (angle > 90)
        angle = 90;
    if (angle < -90)
        angle = -90;

    // 计算脉宽：中间位置1500
    pulse = SERVO_CENTER_PULSE + (uint32_t)(angle * (SERVO_MAX_PULSE - SERVO_MIN_PULSE) / 180);

    // 设置TIMG12的CC0通道（PA10）输出比较值
    DL_TimerG_setCaptureCompareValue(PWM_SERVO_INST, pulse, DL_TIMER_CC_0_INDEX);
}