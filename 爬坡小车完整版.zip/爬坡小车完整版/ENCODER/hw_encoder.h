#include "ti_msp_dl_config.h"
void encoder_init(void);
void TIMER_TICK_INST_IRQHandler(void);

