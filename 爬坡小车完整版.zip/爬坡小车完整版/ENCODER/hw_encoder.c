#include "ti_msp_dl_config.h"
#include "hw_encoder.h"
#include <key.h>
//static ENCODER_RES motor_encoder;

//编码器初始化
void encoder_init(void)
{
	//编码器引脚外部中断
	NVIC_ClearPendingIRQ(GPIOB_INT_IRQn);
	NVIC_EnableIRQ(GPIOB_INT_IRQn);
}



