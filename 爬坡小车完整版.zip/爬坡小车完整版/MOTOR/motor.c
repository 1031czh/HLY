#include "ti_msp_dl_config.h"
#include "motor.h"

/*控制小车运动方向 */
void setCarDirection(uint8_t direction) {
    /* 先清除所有方向引脚 */
    DL_GPIO_clearPins(GPIOB, 
        MOTOR_motor1_PIN | MOTOR_motor2_PIN | 
        MOTOR_motor3_PIN | MOTOR_motor4_PIN);
    
    switch(direction) {
        case CAR_FORWARD:
            /* 左电机正转：IN1=高, IN2=低 */
            DL_GPIO_setPins(MOTOR_PORT, MOTOR_motor2_PIN);
            /* 右电机正转：IN3=高, IN4=低 */
            DL_GPIO_setPins(MOTOR_PORT, MOTOR_motor3_PIN);
            break;
        
        case CAR_BACKWARD:
            /* 左电机反转：IN1=低, IN2=高 */
            DL_GPIO_setPins(MOTOR_PORT, MOTOR_motor1_PIN);
            /* 右电机反转：IN3=低, IN4=高 */
            DL_GPIO_setPins(MOTOR_PORT, MOTOR_motor4_PIN);
            break;
        
        default:
            /* 停止所有电机 */
            break;
    }
}