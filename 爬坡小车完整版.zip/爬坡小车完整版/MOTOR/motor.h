#include "ti_msp_dl_config.h"

/* 电机方向控制宏定义 */
#define CAR_FORWARD  0x01
#define CAR_BACKWARD 0x02


void setCarDirection(uint8_t direction);