################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../SENSOR/IIC.c \
../SENSOR/Uart.c \
../SENSOR/gw_xunji.c 

C_DEPS += \
./SENSOR/IIC.d \
./SENSOR/Uart.d \
./SENSOR/gw_xunji.d 

OBJS += \
./SENSOR/IIC.o \
./SENSOR/Uart.o \
./SENSOR/gw_xunji.o 

OBJS__QUOTED += \
"SENSOR\IIC.o" \
"SENSOR\Uart.o" \
"SENSOR\gw_xunji.o" 

C_DEPS__QUOTED += \
"SENSOR\IIC.d" \
"SENSOR\Uart.d" \
"SENSOR\gw_xunji.d" 

C_SRCS__QUOTED += \
"../SENSOR/IIC.c" \
"../SENSOR/Uart.c" \
"../SENSOR/gw_xunji.c" 


