################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../HUIDU/huidu.c 

C_DEPS += \
./HUIDU/huidu.d 

OBJS += \
./HUIDU/huidu.o 

OBJS__QUOTED += \
"HUIDU\huidu.o" 

C_DEPS__QUOTED += \
"HUIDU\huidu.d" 

C_SRCS__QUOTED += \
"../HUIDU/huidu.c" 


