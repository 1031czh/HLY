################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
HUIDU/%.o: ../HUIDU/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: Arm Compiler'
	"C:/ti/ccs2030/ccs/tools/compiler/ti-cgt-armllvm_4.0.3.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O0 -I"C:/Users/HLY/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/PWM" -I"C:/Users/HLY/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/MOTOR" -I"C:/Users/HLY/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/SERVO" -I"C:/Users/HLY/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/DELAY" -I"C:/Users/HLY/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/SENSOR" -I"C:/Users/HLY/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/HUIDU" -I"C:/Users/HLY/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/PID" -I"C:/Users/HLY/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/FMQ" -I"C:/Users/HLY/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/KEY" -I"C:/Users/HLY/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/ENCODER" -I"C:/Users/HLY/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang" -I"C:/Users/HLY/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/Debug" -I"C:/ti/mspm0_sdk_2_06_00_05/source/third_party/CMSIS/Core/Include" -I"C:/ti/mspm0_sdk_2_06_00_05/source" -I"C:/Users/HLY/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/OLED" -gdwarf-3 -MMD -MP -MF"HUIDU/$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


