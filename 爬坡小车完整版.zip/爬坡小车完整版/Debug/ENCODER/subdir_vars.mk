################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ENCODER/hw_encoder.c 

C_DEPS += \
./ENCODER/hw_encoder.d 

OBJS += \
./ENCODER/hw_encoder.o 

OBJS__QUOTED += \
"ENCODER\hw_encoder.o" 

C_DEPS__QUOTED += \
"ENCODER\hw_encoder.d" 

C_SRCS__QUOTED += \
"../ENCODER/hw_encoder.c" 


