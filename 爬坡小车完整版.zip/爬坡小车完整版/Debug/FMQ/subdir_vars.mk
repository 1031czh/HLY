################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../FMQ/fmq.c 

C_DEPS += \
./FMQ/fmq.d 

OBJS += \
./FMQ/fmq.o 

OBJS__QUOTED += \
"FMQ\fmq.o" 

C_DEPS__QUOTED += \
"FMQ\fmq.d" 

C_SRCS__QUOTED += \
"../FMQ/fmq.c" 


