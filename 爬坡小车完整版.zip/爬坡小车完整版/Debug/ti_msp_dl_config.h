/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)


#define CPUCLK_FREQ                                                     32000000



/* Defines for PWM_0 */
#define PWM_0_INST                                                         TIMG0
#define PWM_0_INST_IRQHandler                                   TIMG0_IRQHandler
#define PWM_0_INST_INT_IRQN                                     (TIMG0_INT_IRQn)
#define PWM_0_INST_CLK_FREQ                                              8000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_0_C0_PORT                                                 GPIOA
#define GPIO_PWM_0_C0_PIN                                         DL_GPIO_PIN_12
#define GPIO_PWM_0_C0_IOMUX                                      (IOMUX_PINCM34)
#define GPIO_PWM_0_C0_IOMUX_FUNC                     IOMUX_PINCM34_PF_TIMG0_CCP0
#define GPIO_PWM_0_C0_IDX                                    DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_PWM_0_C1_PORT                                                 GPIOA
#define GPIO_PWM_0_C1_PIN                                         DL_GPIO_PIN_13
#define GPIO_PWM_0_C1_IOMUX                                      (IOMUX_PINCM35)
#define GPIO_PWM_0_C1_IOMUX_FUNC                     IOMUX_PINCM35_PF_TIMG0_CCP1
#define GPIO_PWM_0_C1_IDX                                    DL_TIMER_CC_1_INDEX

/* Defines for PWM_SERVO */
#define PWM_SERVO_INST                                                     TIMG8
#define PWM_SERVO_INST_IRQHandler                               TIMG8_IRQHandler
#define PWM_SERVO_INST_INT_IRQN                                 (TIMG8_INT_IRQn)
#define PWM_SERVO_INST_CLK_FREQ                                          1000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_SERVO_C0_PORT                                             GPIOB
#define GPIO_PWM_SERVO_C0_PIN                                      DL_GPIO_PIN_6
#define GPIO_PWM_SERVO_C0_IOMUX                                  (IOMUX_PINCM23)
#define GPIO_PWM_SERVO_C0_IOMUX_FUNC                 IOMUX_PINCM23_PF_TIMG8_CCP0
#define GPIO_PWM_SERVO_C0_IDX                                DL_TIMER_CC_0_INDEX



/* Defines for TIMER_TICK */
#define TIMER_TICK_INST                                                  (TIMA0)
#define TIMER_TICK_INST_IRQHandler                              TIMA0_IRQHandler
#define TIMER_TICK_INST_INT_IRQN                                (TIMA0_INT_IRQn)
#define TIMER_TICK_INST_LOAD_VALUE                                       (9999U)
/* Defines for TIMER_SUDU */
#define TIMER_SUDU_INST                                                  (TIMG6)
#define TIMER_SUDU_INST_IRQHandler                              TIMG6_IRQHandler
#define TIMER_SUDU_INST_INT_IRQN                                (TIMG6_INT_IRQn)
#define TIMER_SUDU_INST_LOAD_VALUE                                       (3999U)




/* Port definition for Pin Group FengMing */
#define FengMing_PORT                                                    (GPIOA)

/* Defines for PIN_0: GPIOA.14 with pinCMx 36 on package pin 7 */
#define FengMing_PIN_0_PIN                                      (DL_GPIO_PIN_14)
#define FengMing_PIN_0_IOMUX                                     (IOMUX_PINCM36)
/* Port definition for Pin Group MOTOR */
#define MOTOR_PORT                                                       (GPIOB)

/* Defines for motor1: GPIOB.13 with pinCMx 30 on package pin 1 */
#define MOTOR_motor1_PIN                                        (DL_GPIO_PIN_13)
#define MOTOR_motor1_IOMUX                                       (IOMUX_PINCM30)
/* Defines for motor2: GPIOB.14 with pinCMx 31 on package pin 2 */
#define MOTOR_motor2_PIN                                        (DL_GPIO_PIN_14)
#define MOTOR_motor2_IOMUX                                       (IOMUX_PINCM31)
/* Defines for motor3: GPIOB.15 with pinCMx 32 on package pin 3 */
#define MOTOR_motor3_PIN                                        (DL_GPIO_PIN_15)
#define MOTOR_motor3_IOMUX                                       (IOMUX_PINCM32)
/* Defines for motor4: GPIOB.16 with pinCMx 33 on package pin 4 */
#define MOTOR_motor4_PIN                                        (DL_GPIO_PIN_16)
#define MOTOR_motor4_IOMUX                                       (IOMUX_PINCM33)
/* Port definition for Pin Group huidu */
#define huidu_PORT                                                       (GPIOA)

/* Defines for DAT: GPIOA.31 with pinCMx 6 on package pin 39 */
#define huidu_DAT_PIN                                           (DL_GPIO_PIN_31)
#define huidu_DAT_IOMUX                                           (IOMUX_PINCM6)
/* Defines for CLK: GPIOA.28 with pinCMx 3 on package pin 35 */
#define huidu_CLK_PIN                                           (DL_GPIO_PIN_28)
#define huidu_CLK_IOMUX                                           (IOMUX_PINCM3)
/* Port definition for Pin Group I2C */
#define I2C_PORT                                                         (GPIOB)

/* Defines for SCL: GPIOB.2 with pinCMx 15 on package pin 50 */
#define I2C_SCL_PIN                                              (DL_GPIO_PIN_2)
#define I2C_SCL_IOMUX                                            (IOMUX_PINCM15)
/* Defines for SDA: GPIOB.3 with pinCMx 16 on package pin 51 */
#define I2C_SDA_PIN                                              (DL_GPIO_PIN_3)
#define I2C_SDA_IOMUX                                            (IOMUX_PINCM16)
/* Port definition for Pin Group KEY */
#define KEY_PORT                                                         (GPIOA)

/* Defines for PIN_18: GPIOA.18 with pinCMx 40 on package pin 11 */
// pins affected by this interrupt request:["PIN_18","PIN_17"]
#define KEY_INT_IRQN                                            (GPIOA_INT_IRQn)
#define KEY_INT_IIDX                            (DL_INTERRUPT_GROUP1_IIDX_GPIOA)
#define KEY_PIN_18_IIDX                                     (DL_GPIO_IIDX_DIO18)
#define KEY_PIN_18_PIN                                          (DL_GPIO_PIN_18)
#define KEY_PIN_18_IOMUX                                         (IOMUX_PINCM40)
/* Defines for PIN_17: GPIOA.17 with pinCMx 39 on package pin 10 */
#define KEY_PIN_17_IIDX                                     (DL_GPIO_IIDX_DIO17)
#define KEY_PIN_17_PIN                                          (DL_GPIO_PIN_17)
#define KEY_PIN_17_IOMUX                                         (IOMUX_PINCM39)
/* Port definition for Pin Group GPIO_ENCODER */
#define GPIO_ENCODER_PORT                                                (GPIOB)

/* Defines for PIN_A: GPIOB.0 with pinCMx 12 on package pin 47 */
// pins affected by this interrupt request:["PIN_A","PIN_B"]
#define GPIO_ENCODER_INT_IRQN                                   (GPIOB_INT_IRQn)
#define GPIO_ENCODER_INT_IIDX                   (DL_INTERRUPT_GROUP1_IIDX_GPIOB)
#define GPIO_ENCODER_PIN_A_IIDX                              (DL_GPIO_IIDX_DIO0)
#define GPIO_ENCODER_PIN_A_PIN                                   (DL_GPIO_PIN_0)
#define GPIO_ENCODER_PIN_A_IOMUX                                 (IOMUX_PINCM12)
/* Defines for PIN_B: GPIOB.1 with pinCMx 13 on package pin 48 */
#define GPIO_ENCODER_PIN_B_IIDX                              (DL_GPIO_IIDX_DIO1)
#define GPIO_ENCODER_PIN_B_PIN                                   (DL_GPIO_PIN_1)
#define GPIO_ENCODER_PIN_B_IOMUX                                 (IOMUX_PINCM13)


/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_PWM_0_init(void);
void SYSCFG_DL_PWM_SERVO_init(void);
void SYSCFG_DL_TIMER_TICK_init(void);
void SYSCFG_DL_TIMER_SUDU_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
