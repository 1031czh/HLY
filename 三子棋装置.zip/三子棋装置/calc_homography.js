const fs = require('fs');

const u = [443, 335, 551, 447, 338, 555, 450, 341, 559];
const v = [259, 256, 262, 173, 168, 176,  85,  81,  89];
const X = [0.0, -3.2, 3.2, 0.0, -3.2, 3.2, 0.0, -3.2, 3.2];
const Y = [28.0, 28.0, 28.0, 31.2, 31.2, 31.2, 34.4, 34.4, 34.4];

let A = [];
let B = [];

for (let i = 0; i < u.length; i++) {
    // Equation for X
    A.push([u[i], v[i], 1, 0, 0, 0, -X[i]*u[i], -X[i]*v[i]]);
    B.push([X[i]]);
    
    // Equation for Y
    A.push([0, 0, 0, u[i], v[i], 1, -Y[i]*u[i], -Y[i]*v[i]]);
    B.push([Y[i]]);
}

function transpose(m) {
    let res = [];
    for (let j = 0; j < m[0].length; j++) {
        let row = [];
        for (let i = 0; i < m.length; i++) {
            row.push(m[i][j]);
        }
        res.push(row);
    }
    return res;
}

function multiply(m1, m2) {
    let res = [];
    for (let i = 0; i < m1.length; i++) {
        let row = [];
        for (let j = 0; j < m2[0].length; j++) {
            let sum = 0;
            for (let k = 0; k < m1[0].length; k++) {
                sum += m1[i][k] * m2[k][j];
            }
            row.push(sum);
        }
        res.push(row);
    }
    return res;
}

function invertMatrix(M) {
    let n = M.length;
    let a = [];
    for(let i=0; i<n; i++) {
        a[i] = [];
        for(let j=0; j<n; j++) a[i][j] = M[i][j];
        for(let j=n; j<2*n; j++) a[i][j] = (j-n === i) ? 1 : 0;
    }
    for(let i=0; i<n; i++) {
        let maxRow = i;
        for(let j=i+1; j<n; j++) {
            if(Math.abs(a[j][i]) > Math.abs(a[maxRow][i])) maxRow = j;
        }
        let temp = a[i]; a[i] = a[maxRow]; a[maxRow] = temp;
        
        let lead = a[i][i];
        for(let j=0; j<2*n; j++) a[i][j] /= lead;
        
        for(let j=0; j<n; j++) {
            if(i !== j) {
                let f = a[j][i];
                for(let k=0; k<2*n; k++) a[j][k] -= f * a[i][k];
            }
        }
    }
    let res = [];
    for(let i=0; i<n; i++) {
        res[i] = [];
        for(let j=0; j<n; j++) res[i].push(a[i][j+n]);
    }
    return res;
}

let AT = transpose(A);
let ATA = multiply(AT, A);
let invATA = invertMatrix(ATA);
let pinvA = multiply(invATA, AT);
let H = multiply(pinvA, B);

console.log("H11 =", H[0][0]);
console.log("H12 =", H[1][0]);
console.log("H13 =", H[2][0]);
console.log("H21 =", H[3][0]);
console.log("H22 =", H[4][0]);
console.log("H23 =", H[5][0]);
console.log("H31 =", H[6][0]);
console.log("H32 =", H[7][0]);
