#include "ti_msp_dl_config.h"
#include "uart.h"

// ---- UART_Map (UART3) 红色方框数据全局变量 ----
Point2D g_map_rects[MAX_POINTS];
uint8_t g_map_rect_count = 0;
volatile uint8_t g_map_data_ready = 0; // 标志位：1 表示收到一帧完整且校验成功的数据
PhysPoint2D g_map_phys[MAX_POINTS]; // 仿射变换后的地图物理坐标

// ---- UART_Target (UART2) 红色色块数据全局变量 ----
Point2D g_target_blobs[MAX_POINTS];
uint8_t g_target_blob_count = 0;
volatile uint8_t g_target_data_ready = 0;
PhysPoint2D g_target_phys[MAX_POINTS];

// ---- UART_Target (UART2) 黑棋外数据全局变量 ----
Point2D g_black_out_blobs[MAX_POINTS];
uint8_t g_black_out_blob_count = 0;
volatile uint8_t g_black_out_data_ready = 0;
PhysPoint2D g_black_out_phys[MAX_POINTS];

// ---- UART_Target (UART2) 黑棋内数据全局变量 ----
Point2D g_black_in_blobs[MAX_POINTS];
uint8_t g_black_in_blob_count = 0;
volatile uint8_t g_black_in_data_ready = 0;
PhysPoint2D g_black_in_phys[MAX_POINTS];

// ---- UART_Target (UART2) 白棋外数据全局变量 ----
Point2D g_white_out_blobs[MAX_POINTS];
uint8_t g_white_out_blob_count = 0;
volatile uint8_t g_white_out_data_ready = 0;
PhysPoint2D g_white_out_phys[MAX_POINTS];

// ---- UART_Target (UART2) 白棋内数据全局变量 ----
Point2D g_white_in_blobs[MAX_POINTS];
uint8_t g_white_in_blob_count = 0;
volatile uint8_t g_white_in_data_ready = 0;
PhysPoint2D g_white_in_phys[MAX_POINTS];


static inline void affine_transform(uint16_t px, uint16_t py, float *out_x, float *out_y)
{
    // 重新计算的精确单应性矩阵 (Homography Transform)
    float den = 0.0000529608f * px + 0.0000295995f * py + 1.0f;
    *out_x =  (0.0302658444f * px + 0.0007748622f * py - 13.3662661405f) / den;
    *out_y =  (0.0021144877f * px - 0.0365085274f * py + 37.2603056378f) / den;
}


// ===== UART_Target (UART2) 中断处理 =====
// 支持五种帧头：0xBB(红棋) / 0xCC(黑外) / 0xEE(黑内) / 0xDD(白外) / 0xEF(白内)
void UART_Target_INST_IRQHandler(void) {
    static RxStatus_t rx_status = STATUS_WAIT_HEADER;
    static uint8_t current_header = 0;   // 记住当前帧的帧头类型
    static uint8_t expected_count = 0;
    static uint8_t byte_index = 0;
    static uint8_t checksum = 0;
    static uint8_t temp_buf[MAX_POINTS * 4];

    switch (DL_UART_getPendingInterrupt(UART_Target_INST)) {
        case DL_UART_IIDX_RX: {
            uint8_t rx_byte = DL_UART_receiveData(UART_Target_INST);

            switch (rx_status) {
                case STATUS_WAIT_HEADER:
                    if (rx_byte == 0xBB || rx_byte == 0xCC || rx_byte == 0xEE || rx_byte == 0xDD || rx_byte == 0xEF) {
                        current_header = rx_byte;
                        rx_status = STATUS_WAIT_COUNT;
                    }
                    break;

                case STATUS_WAIT_COUNT:
                    expected_count = rx_byte;
                    checksum = expected_count;
                    byte_index = 0;
                    if (expected_count == 0) {
                        rx_status = STATUS_WAIT_CHECKSUM;
                    } else if (expected_count > MAX_POINTS) {
                        rx_status = STATUS_WAIT_HEADER;
                    } else {
                        rx_status = STATUS_RECEIVING_DATA;
                    }
                    break;

                case STATUS_RECEIVING_DATA:
                    temp_buf[byte_index++] = rx_byte;
                    checksum += rx_byte;
                    if (byte_index >= (expected_count * 4)) {
                        rx_status = STATUS_WAIT_CHECKSUM;
                    }
                    break;

                case STATUS_WAIT_CHECKSUM:
                    if (rx_byte == (checksum & 0xFF)) {
                        rx_status = STATUS_WAIT_TAIL;
                    } else {
                        rx_status = STATUS_WAIT_HEADER;
                    }
                    break;

                case STATUS_WAIT_TAIL:
                    if (rx_byte == 0x55) { // 帧尾
                        // 根据帧头类型分发到对应的全局数组
                        switch (current_header) {
                            case 0xBB: // 红棋
                                for (int i = 0; i < expected_count; i++) {
                                    uint16_t px = (temp_buf[i * 4] << 8) | temp_buf[i * 4 + 1];
                                    uint16_t py = (temp_buf[i * 4 + 2] << 8) | temp_buf[i * 4 + 3];
                                    g_target_blobs[i].x = px;
                                    g_target_blobs[i].y = py;
                                    affine_transform(px, py, &g_target_phys[i].x, &g_target_phys[i].y);
                                }
                                g_target_blob_count = expected_count;
                                g_target_data_ready = 1;
                                break;

                            case 0xCC: // 黑棋外
                                for (int i = 0; i < expected_count; i++) {
                                    uint16_t px = (temp_buf[i * 4] << 8) | temp_buf[i * 4 + 1];
                                    uint16_t py = (temp_buf[i * 4 + 2] << 8) | temp_buf[i * 4 + 3];
                                    g_black_out_blobs[i].x = px;
                                    g_black_out_blobs[i].y = py;
                                    affine_transform(px, py, &g_black_out_phys[i].x, &g_black_out_phys[i].y);
                                }
                                g_black_out_blob_count = expected_count;
                                g_black_out_data_ready = 1;
                                break;

                            case 0xEE: // 黑棋内
                                for (int i = 0; i < expected_count; i++) {
                                    uint16_t px = (temp_buf[i * 4] << 8) | temp_buf[i * 4 + 1];
                                    uint16_t py = (temp_buf[i * 4 + 2] << 8) | temp_buf[i * 4 + 3];
                                    g_black_in_blobs[i].x = px;
                                    g_black_in_blobs[i].y = py;
                                    affine_transform(px, py, &g_black_in_phys[i].x, &g_black_in_phys[i].y);
                                }
                                g_black_in_blob_count = expected_count;
                                g_black_in_data_ready = 1;
                                break;

                            case 0xDD: // 白棋外
                                for (int i = 0; i < expected_count; i++) {
                                    uint16_t px = (temp_buf[i * 4] << 8) | temp_buf[i * 4 + 1];
                                    uint16_t py = (temp_buf[i * 4 + 2] << 8) | temp_buf[i * 4 + 3];
                                    g_white_out_blobs[i].x = px;
                                    g_white_out_blobs[i].y = py;
                                    affine_transform(px, py, &g_white_out_phys[i].x, &g_white_out_phys[i].y);
                                }
                                g_white_out_blob_count = expected_count;
                                g_white_out_data_ready = 1;
                                break;

                            case 0xEF: // 白棋内
                                for (int i = 0; i < expected_count; i++) {
                                    uint16_t px = (temp_buf[i * 4] << 8) | temp_buf[i * 4 + 1];
                                    uint16_t py = (temp_buf[i * 4 + 2] << 8) | temp_buf[i * 4 + 3];
                                    g_white_in_blobs[i].x = px;
                                    g_white_in_blobs[i].y = py;
                                    affine_transform(px, py, &g_white_in_phys[i].x, &g_white_in_phys[i].y);
                                }
                                g_white_in_blob_count = expected_count;
                                g_white_in_data_ready = 1;
                                break;
                        }
                    }
                    rx_status = STATUS_WAIT_HEADER;
                    break;

                default:
                    rx_status = STATUS_WAIT_HEADER;
                    break;
            }
            break;
        }
        default:
            // 发生错误时（如电磁噪声引起的帧错误、溢出等），清空所有错误标志位，避免 UART 永远挂死
            DL_UART_clearInterruptStatus(UART_Target_INST, 0xFFFFFFFF);
            while (DL_UART_isRXFIFOEmpty(UART_Target_INST) == false) {
                DL_UART_receiveData(UART_Target_INST);
            }
            rx_status = STATUS_WAIT_HEADER;
            break;
    }
}



void UART_Map_INST_IRQHandler(void) {
    static RxStatus_t rx_status = STATUS_WAIT_HEADER;
    static uint8_t expected_count = 0;
    static uint8_t byte_index = 0;
    static uint8_t checksum = 0;
    static uint8_t temp_buf[MAX_POINTS * 4]; // 临时缓冲区，用于暂存坐标字节

    switch (DL_UART_getPendingInterrupt(UART_Map_INST)) {
        case DL_UART_IIDX_RX: { // 接收到单字节中断
            uint8_t rx_byte = DL_UART_receiveData(UART_Map_INST);

            switch (rx_status) {
                case STATUS_WAIT_HEADER:
                    if (rx_byte == 0xAA) { // 红色方框帧头
                        rx_status = STATUS_WAIT_COUNT;
                    }
                    break;

                case STATUS_WAIT_COUNT:
                    expected_count = rx_byte;
                    checksum = expected_count;
                    byte_index = 0;
                    if (expected_count == 0) {
                        rx_status = STATUS_WAIT_CHECKSUM;
                    } else if (expected_count > MAX_POINTS) {
                        rx_status = STATUS_WAIT_HEADER; // 数量非法，复位
                    } else {
                        rx_status = STATUS_RECEIVING_DATA;
                    }
                    break;

                case STATUS_RECEIVING_DATA:
                    temp_buf[byte_index++] = rx_byte;
                    checksum += rx_byte;
                    if (byte_index >= (expected_count * 4)) {
                        rx_status = STATUS_WAIT_CHECKSUM;
                    }
                    break;

                case STATUS_WAIT_CHECKSUM:
                    if (rx_byte == (checksum & 0xFF)) {
                        rx_status = STATUS_WAIT_TAIL;
                    } else {
                        rx_status = STATUS_WAIT_HEADER; // 校验失败，丢弃
                    }
                    break;

                case STATUS_WAIT_TAIL:
                    if (rx_byte == 0x55) { // 帧尾验证成功
                        // 棋盘格点数固定为 9 点。只有当新接收到的点数正好为 9 时，才更新地图数据，彻底防遮挡和噪声干扰
                        if (expected_count == 9) {
                            for (int i = 0; i < 9; i++) {
                                uint16_t px = (temp_buf[i * 4] << 8) | temp_buf[i * 4 + 1];
                                uint16_t py = (temp_buf[i * 4 + 2] << 8) | temp_buf[i * 4 + 3];
                                g_map_rects[i].x = px;
                                g_map_rects[i].y = py;
                                affine_transform(px, py, &g_map_phys[i].x, &g_map_phys[i].y);
                            }
                            g_map_rect_count = 9;
                            g_map_data_ready = 1; // 触发通知标志
                        }
                    }
                    rx_status = STATUS_WAIT_HEADER; // 无论尾部是否正确，重新进入等待状态
                    break;

                default:
                    rx_status = STATUS_WAIT_HEADER;
                    break;
            }
            break;
        }
        default:
            // 发生错误时（如电磁噪声引起的帧错误、溢出等），清空所有错误标志位，避免 UART 永远挂死
            DL_UART_clearInterruptStatus(UART_Map_INST, 0xFFFFFFFF);
            while (DL_UART_isRXFIFOEmpty(UART_Map_INST) == false) {
                DL_UART_receiveData(UART_Map_INST);
            }
            rx_status = STATUS_WAIT_HEADER;
            break;
    }
}