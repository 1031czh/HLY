#ifndef UART_H_
#define UART_H_

#include "ti_msp_dl_config.h"

// 限制最大支持的矩形/色块数量，防止内存溢出
#define MAX_POINTS 18 

// 定义像素点坐标结构体
typedef struct {
    uint16_t x;
    uint16_t y;
} Point2D;

// 定义物理坐标结构体（单位：cm）
typedef struct {
    float x;
    float y;
} PhysPoint2D;

// 定义接收状态机枚举
typedef enum {
    STATUS_WAIT_HEADER = 0,
    STATUS_WAIT_COUNT,
    STATUS_RECEIVING_DATA,
    STATUS_WAIT_CHECKSUM,
    STATUS_WAIT_TAIL
} RxStatus_t;

// ---- UART_Map (UART3) 红色方框/棋盘格数据 ----
extern Point2D g_map_rects[];
extern uint8_t g_map_rect_count;
extern volatile uint8_t g_map_data_ready;
extern PhysPoint2D g_map_phys[];

// ---- UART_Target (UART2) 红色色块数据 ----
extern Point2D g_target_blobs[];
extern uint8_t g_target_blob_count;
extern volatile uint8_t g_target_data_ready;
extern PhysPoint2D g_target_phys[];

// ---- UART_Target (UART2) 黑棋外部(外)数据 ----
extern Point2D g_black_out_blobs[];
extern uint8_t g_black_out_blob_count;
extern volatile uint8_t g_black_out_data_ready;
extern PhysPoint2D g_black_out_phys[];

// ---- UART_Target (UART2) 黑棋内部(内)数据 ----
extern Point2D g_black_in_blobs[];
extern uint8_t g_black_in_blob_count;
extern volatile uint8_t g_black_in_data_ready;
extern PhysPoint2D g_black_in_phys[];

// ---- UART_Target (UART2) 白棋外部(外)数据 ----
extern Point2D g_white_out_blobs[];
extern uint8_t g_white_out_blob_count;
extern volatile uint8_t g_white_out_data_ready;
extern PhysPoint2D g_white_out_phys[];

// ---- UART_Target (UART2) 白棋内部(内)数据 ----
extern Point2D g_white_in_blobs[];
extern uint8_t g_white_in_blob_count;
extern volatile uint8_t g_white_in_data_ready;
extern PhysPoint2D g_white_in_phys[];

#endif /* UART_H_ */
