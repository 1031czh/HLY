$u = @(445, 327, 560, 446, 330, 562, 448, 333, 563)
$v = @(309, 309, 311, 219, 217, 220, 127, 126, 129)
$X = @(0.0, -3.2, 3.2, 0.0, -3.2, 3.2, 0.0, -3.2, 3.2)
$Y = @(28.0, 28.0, 28.0, 31.2, 31.2, 31.2, 34.4, 34.4, 34.4)

$A = New-Object 'double[][]' 18
$b = New-Object 'double[]' 18

for ($i = 0; $i -lt 9; $i++) {
    $A[2*$i] = @([double]$u[$i], [double]$v[$i], 1.0, 0.0, 0.0, 0.0, [double](-$u[$i]*$X[$i]), [double](-$v[$i]*$X[$i]))
    $A[2*$i+1] = @(0.0, 0.0, 0.0, [double]$u[$i], [double]$v[$i], 1.0, [double](-$u[$i]*$Y[$i]), [double](-$v[$i]*$Y[$i]))
    $b[2*$i] = [double]$X[$i]
    $b[2*$i+1] = [double]$Y[$i]
}

# At
$At = New-Object 'double[][]' 8
for ($i = 0; $i -lt 8; $i++) {
    $At[$i] = New-Object 'double[]' 18
    for ($j = 0; $j -lt 18; $j++) {
        $At[$i][$j] = $A[$j][$i]
    }
}

# AtA
$AtA = New-Object 'double[][]' 8
for ($i = 0; $i -lt 8; $i++) {
    $AtA[$i] = New-Object 'double[]' 8
    for ($j = 0; $j -lt 8; $j++) {
        $sum = 0.0
        for ($k = 0; $k -lt 18; $k++) {
            $sum += $At[$i][$k] * $A[$k][$j]
        }
        $AtA[$i][$j] = $sum
    }
}

# Atb
$Atb = New-Object 'double[]' 8
for ($i = 0; $i -lt 8; $i++) {
    $sum = 0.0
    for ($k = 0; $k -lt 18; $k++) {
        $sum += $At[$i][$k] * $b[$k]
    }
    $Atb[$i] = $sum
}

# Gaussian elimination
$n = 8
for ($i = 0; $i -lt $n; $i++) {
    $pivot = $i
    for ($j = $i + 1; $j -lt $n; $j++) {
        if ([Math]::Abs($AtA[$j][$i]) -gt [Math]::Abs($AtA[$pivot][$i])) {
            $pivot = $j
        }
    }
    # Swap
    $temp = $AtA[$i]
    $AtA[$i] = $AtA[$pivot]
    $AtA[$pivot] = $temp
    
    $temp = $Atb[$i]
    $Atb[$i] = $Atb[$pivot]
    $Atb[$pivot] = $temp
    
    for ($j = $i + 1; $j -lt $n; $j++) {
        $factor = $AtA[$j][$i] / $AtA[$i][$i]
        for ($k = $i; $k -lt $n; $k++) {
            $AtA[$j][$k] -= $factor * $AtA[$i][$k]
        }
        $Atb[$j] -= $factor * $Atb[$i]
    }
}

$x_sol = New-Object 'double[]' $n
for ($i = $n - 1; $i -ge 0; $i--) {
    $s = 0.0
    for ($j = $i + 1; $j -lt $n; $j++) {
        $s += $AtA[$i][$j] * $x_sol[$j]
    }
    $x_sol[$i] = ($Atb[$i] - $s) / $AtA[$i][$i]
}

Write-Host "Homography Matrix H:"
for ($i = 0; $i -lt 8; $i++) {
    Write-Host "H$i =" $x_sol[$i]
}

Write-Host ""
Write-Host "Verify:"
for ($i = 0; $i -lt 9; $i++) {
    $w = $x_sol[6]*$u[$i] + $x_sol[7]*$v[$i] + 1.0
    $pred_X = ($x_sol[0]*$u[$i] + $x_sol[1]*$v[$i] + $x_sol[2]) / $w
    $pred_Y = ($x_sol[3]*$u[$i] + $x_sol[4]*$v[$i] + $x_sol[5]) / $w
    $err_X = $pred_X - $X[$i]
    $err_Y = $pred_Y - $Y[$i]
    Write-Host "P$i Target: $($X[$i]), $($Y[$i]) -> Pred: $pred_X, $pred_Y | Err: $err_X, $err_Y"
}
