/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)



#define CPUCLK_FREQ                                                     32000000



/* Defines for PWM_SERVO */
#define PWM_SERVO_INST                                                     TIMG8
#define PWM_SERVO_INST_IRQHandler                               TIMG8_IRQHandler
#define PWM_SERVO_INST_INT_IRQN                                 (TIMG8_INT_IRQn)
#define PWM_SERVO_INST_CLK_FREQ                                          1000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_SERVO_C0_PORT                                             GPIOB
#define GPIO_PWM_SERVO_C0_PIN                                     DL_GPIO_PIN_21
#define GPIO_PWM_SERVO_C0_IOMUX                                  (IOMUX_PINCM49)
#define GPIO_PWM_SERVO_C0_IOMUX_FUNC                 IOMUX_PINCM49_PF_TIMG8_CCP0
#define GPIO_PWM_SERVO_C0_IDX                                DL_TIMER_CC_0_INDEX



/* Defines for UART_Left */
#define UART_Left_INST                                                     UART0
#define UART_Left_INST_FREQUENCY                                         4000000
#define UART_Left_INST_IRQHandler                               UART0_IRQHandler
#define UART_Left_INST_INT_IRQN                                   UART0_INT_IRQn
#define GPIO_UART_Left_RX_PORT                                             GPIOA
#define GPIO_UART_Left_TX_PORT                                             GPIOA
#define GPIO_UART_Left_RX_PIN                                     DL_GPIO_PIN_11
#define GPIO_UART_Left_TX_PIN                                     DL_GPIO_PIN_10
#define GPIO_UART_Left_IOMUX_RX                                  (IOMUX_PINCM22)
#define GPIO_UART_Left_IOMUX_TX                                  (IOMUX_PINCM21)
#define GPIO_UART_Left_IOMUX_RX_FUNC                   IOMUX_PINCM22_PF_UART0_RX
#define GPIO_UART_Left_IOMUX_TX_FUNC                   IOMUX_PINCM21_PF_UART0_TX
#define UART_Left_BAUD_RATE                                             (115200)
#define UART_Left_IBRD_4_MHZ_115200_BAUD                                     (2)
#define UART_Left_FBRD_4_MHZ_115200_BAUD                                    (11)
/* Defines for UART_Right */
#define UART_Right_INST                                                    UART1
#define UART_Right_INST_FREQUENCY                                        4000000
#define UART_Right_INST_IRQHandler                              UART1_IRQHandler
#define UART_Right_INST_INT_IRQN                                  UART1_INT_IRQn
#define GPIO_UART_Right_RX_PORT                                            GPIOB
#define GPIO_UART_Right_TX_PORT                                            GPIOB
#define GPIO_UART_Right_RX_PIN                                     DL_GPIO_PIN_5
#define GPIO_UART_Right_TX_PIN                                     DL_GPIO_PIN_6
#define GPIO_UART_Right_IOMUX_RX                                 (IOMUX_PINCM18)
#define GPIO_UART_Right_IOMUX_TX                                 (IOMUX_PINCM23)
#define GPIO_UART_Right_IOMUX_RX_FUNC                  IOMUX_PINCM18_PF_UART1_RX
#define GPIO_UART_Right_IOMUX_TX_FUNC                  IOMUX_PINCM23_PF_UART1_TX
#define UART_Right_BAUD_RATE                                            (115200)
#define UART_Right_IBRD_4_MHZ_115200_BAUD                                    (2)
#define UART_Right_FBRD_4_MHZ_115200_BAUD                                   (11)
/* Defines for UART_Target */
#define UART_Target_INST                                                   UART2
#define UART_Target_INST_FREQUENCY                                      32000000
#define UART_Target_INST_IRQHandler                             UART2_IRQHandler
#define UART_Target_INST_INT_IRQN                                 UART2_INT_IRQn
#define GPIO_UART_Target_RX_PORT                                           GPIOB
#define GPIO_UART_Target_TX_PORT                                           GPIOB
#define GPIO_UART_Target_RX_PIN                                   DL_GPIO_PIN_16
#define GPIO_UART_Target_TX_PIN                                   DL_GPIO_PIN_15
#define GPIO_UART_Target_IOMUX_RX                                (IOMUX_PINCM33)
#define GPIO_UART_Target_IOMUX_TX                                (IOMUX_PINCM32)
#define GPIO_UART_Target_IOMUX_RX_FUNC                 IOMUX_PINCM33_PF_UART2_RX
#define GPIO_UART_Target_IOMUX_TX_FUNC                 IOMUX_PINCM32_PF_UART2_TX
#define UART_Target_BAUD_RATE                                           (115200)
#define UART_Target_IBRD_32_MHZ_115200_BAUD                                 (17)
#define UART_Target_FBRD_32_MHZ_115200_BAUD                                 (23)
/* Defines for UART_Map */
#define UART_Map_INST                                                      UART3
#define UART_Map_INST_FREQUENCY                                          4000000
#define UART_Map_INST_IRQHandler                                UART3_IRQHandler
#define UART_Map_INST_INT_IRQN                                    UART3_INT_IRQn
#define GPIO_UART_Map_RX_PORT                                              GPIOB
#define GPIO_UART_Map_TX_PORT                                              GPIOB
#define GPIO_UART_Map_RX_PIN                                      DL_GPIO_PIN_13
#define GPIO_UART_Map_TX_PIN                                      DL_GPIO_PIN_12
#define GPIO_UART_Map_IOMUX_RX                                   (IOMUX_PINCM30)
#define GPIO_UART_Map_IOMUX_TX                                   (IOMUX_PINCM29)
#define GPIO_UART_Map_IOMUX_RX_FUNC                    IOMUX_PINCM30_PF_UART3_RX
#define GPIO_UART_Map_IOMUX_TX_FUNC                    IOMUX_PINCM29_PF_UART3_TX
#define UART_Map_BAUD_RATE                                              (115200)
#define UART_Map_IBRD_4_MHZ_115200_BAUD                                      (2)
#define UART_Map_FBRD_4_MHZ_115200_BAUD                                     (11)




/* Defines for OLED */
#define OLED_INST                                                          SPI1
#define OLED_INST_IRQHandler                                    SPI1_IRQHandler
#define OLED_INST_INT_IRQN                                        SPI1_INT_IRQn
#define GPIO_OLED_PICO_PORT                                               GPIOB
#define GPIO_OLED_PICO_PIN                                        DL_GPIO_PIN_8
#define GPIO_OLED_IOMUX_PICO                                    (IOMUX_PINCM25)
#define GPIO_OLED_IOMUX_PICO_FUNC                    IOMUX_PINCM25_PF_SPI1_PICO
/* GPIO configuration for OLED */
#define GPIO_OLED_SCLK_PORT                                               GPIOB
#define GPIO_OLED_SCLK_PIN                                        DL_GPIO_PIN_9
#define GPIO_OLED_IOMUX_SCLK                                    (IOMUX_PINCM26)
#define GPIO_OLED_IOMUX_SCLK_FUNC                    IOMUX_PINCM26_PF_SPI1_SCLK



/* Port definition for Pin Group Relay */
#define Relay_PORT                                                       (GPIOB)

/* Defines for PIN_0: GPIOB.0 with pinCMx 12 on package pin 47 */
#define Relay_PIN_0_PIN                                          (DL_GPIO_PIN_0)
#define Relay_PIN_0_IOMUX                                        (IOMUX_PINCM12)
/* Port definition for Pin Group GPIO_Beef */
#define GPIO_Beef_PORT                                                   (GPIOA)

/* Defines for PIN_4: GPIOA.31 with pinCMx 6 on package pin 39 */
#define GPIO_Beef_PIN_4_PIN                                     (DL_GPIO_PIN_31)
#define GPIO_Beef_PIN_4_IOMUX                                     (IOMUX_PINCM6)
/* Defines for PIN_CS: GPIOA.13 with pinCMx 35 on package pin 6 */
#define GPIO_OLED_PIN_CS_PORT                                            (GPIOA)
#define GPIO_OLED_PIN_CS_PIN                                    (DL_GPIO_PIN_13)
#define GPIO_OLED_PIN_CS_IOMUX                                   (IOMUX_PINCM35)
/* Defines for PIN_DC: GPIOB.11 with pinCMx 28 on package pin 63 */
#define GPIO_OLED_PIN_DC_PORT                                            (GPIOB)
#define GPIO_OLED_PIN_DC_PIN                                    (DL_GPIO_PIN_11)
#define GPIO_OLED_PIN_DC_IOMUX                                   (IOMUX_PINCM28)
/* Defines for PIN_RES: GPIOB.10 with pinCMx 27 on package pin 62 */
#define GPIO_OLED_PIN_RES_PORT                                           (GPIOB)
#define GPIO_OLED_PIN_RES_PIN                                   (DL_GPIO_PIN_10)
#define GPIO_OLED_PIN_RES_IOMUX                                  (IOMUX_PINCM27)
/* Port definition for Pin Group GPIO_Key */
#define GPIO_Key_PORT                                                    (GPIOA)

/* Defines for PIN_1: GPIOA.15 with pinCMx 37 on package pin 8 */
// pins affected by this interrupt request:["PIN_1","PIN_2","PIN_3"]
#define GPIO_Key_INT_IRQN                                       (GPIOA_INT_IRQn)
#define GPIO_Key_INT_IIDX                       (DL_INTERRUPT_GROUP1_IIDX_GPIOA)
#define GPIO_Key_PIN_1_IIDX                                 (DL_GPIO_IIDX_DIO15)
#define GPIO_Key_PIN_1_PIN                                      (DL_GPIO_PIN_15)
#define GPIO_Key_PIN_1_IOMUX                                     (IOMUX_PINCM37)
/* Defines for PIN_2: GPIOA.16 with pinCMx 38 on package pin 9 */
#define GPIO_Key_PIN_2_IIDX                                 (DL_GPIO_IIDX_DIO16)
#define GPIO_Key_PIN_2_PIN                                      (DL_GPIO_PIN_16)
#define GPIO_Key_PIN_2_IOMUX                                     (IOMUX_PINCM38)
/* Defines for PIN_3: GPIOA.17 with pinCMx 39 on package pin 10 */
#define GPIO_Key_PIN_3_IIDX                                 (DL_GPIO_IIDX_DIO17)
#define GPIO_Key_PIN_3_PIN                                      (DL_GPIO_PIN_17)
#define GPIO_Key_PIN_3_IOMUX                                     (IOMUX_PINCM39)


/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_PWM_SERVO_init(void);
void SYSCFG_DL_UART_Left_init(void);
void SYSCFG_DL_UART_Right_init(void);
void SYSCFG_DL_UART_Target_init(void);
void SYSCFG_DL_UART_Map_init(void);
void SYSCFG_DL_OLED_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
