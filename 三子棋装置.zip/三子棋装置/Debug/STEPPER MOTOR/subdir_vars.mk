################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../STEPPER\ MOTOR/stepper\ motor.c 

C_DEPS += \
./STEPPER\ MOTOR/stepper\ motor.d 

OBJS += \
./STEPPER\ MOTOR/stepper\ motor.o 

OBJS__QUOTED += \
"STEPPER MOTOR\stepper motor.o" 

C_DEPS__QUOTED += \
"STEPPER MOTOR\stepper motor.d" 

C_SRCS__QUOTED += \
"../STEPPER MOTOR/stepper motor.c" 


