################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
UART/%.o: ../UART/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: Arm Compiler'
	"C:/ti/ccs2030/ccs/tools/compiler/ti-cgt-armllvm_4.0.3.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O0 -I"C:/Users/HLY/workspace_ccstheia/empty_driverlib_src_LP_MSPM0G3507_nortos_ticlang/HARDWARE/STEPPER MOTOR" -I"C:/Users/HLY/workspace_ccstheia/empty_driverlib_src_LP_MSPM0G3507_nortos_ticlang/DELAY" -I"C:/Users/HLY/workspace_ccstheia/empty_driverlib_src_LP_MSPM0G3507_nortos_ticlang/HARDWARE/RELAY" -I"C:/Users/HLY/workspace_ccstheia/empty_driverlib_src_LP_MSPM0G3507_nortos_ticlang/HARDWARE/OLED" -I"C:/Users/HLY/workspace_ccstheia/empty_driverlib_src_LP_MSPM0G3507_nortos_ticlang/HARDWARE/KEY" -I"C:/Users/HLY/workspace_ccstheia/empty_driverlib_src_LP_MSPM0G3507_nortos_ticlang/HARDWARE/BEEF" -I"C:/Users/HLY/workspace_ccstheia/empty_driverlib_src_LP_MSPM0G3507_nortos_ticlang/HARDWARE/SERVO" -I"C:/Users/HLY/workspace_ccstheia/empty_driverlib_src_LP_MSPM0G3507_nortos_ticlang/HARDWARE/CONFRONT" -I"C:/Users/HLY/workspace_ccstheia/empty_driverlib_src_LP_MSPM0G3507_nortos_ticlang/HARDWARE" -I"C:/Users/HLY/workspace_ccstheia/empty_driverlib_src_LP_MSPM0G3507_nortos_ticlang/UART" -I"C:/Users/HLY/workspace_ccstheia/empty_driverlib_src_LP_MSPM0G3507_nortos_ticlang" -I"C:/Users/HLY/workspace_ccstheia/empty_driverlib_src_LP_MSPM0G3507_nortos_ticlang/Debug" -I"C:/ti/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include" -I"C:/ti/mspm0_sdk_2_10_00_04/source" -gdwarf-3 -Wall -MMD -MP -MF"UART/$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


