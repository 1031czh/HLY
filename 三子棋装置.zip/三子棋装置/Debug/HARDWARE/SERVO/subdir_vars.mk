################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../HARDWARE/SERVO/servo.c 

C_DEPS += \
./HARDWARE/SERVO/servo.d 

OBJS += \
./HARDWARE/SERVO/servo.o 

OBJS__QUOTED += \
"HARDWARE\SERVO\servo.o" 

C_DEPS__QUOTED += \
"HARDWARE\SERVO\servo.d" 

C_SRCS__QUOTED += \
"../HARDWARE/SERVO/servo.c" 


