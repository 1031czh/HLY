################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../HARDWARE/STEPPER\ MOTOR/stepper_motor.c 

C_DEPS += \
./HARDWARE/STEPPER\ MOTOR/stepper_motor.d 

OBJS += \
./HARDWARE/STEPPER\ MOTOR/stepper_motor.o 

OBJS__QUOTED += \
"HARDWARE\STEPPER MOTOR\stepper_motor.o" 

C_DEPS__QUOTED += \
"HARDWARE\STEPPER MOTOR\stepper_motor.d" 

C_SRCS__QUOTED += \
"../HARDWARE/STEPPER MOTOR/stepper_motor.c" 


