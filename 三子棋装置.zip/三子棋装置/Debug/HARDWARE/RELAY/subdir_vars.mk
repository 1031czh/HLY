################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../HARDWARE/RELAY/relay.c 

C_DEPS += \
./HARDWARE/RELAY/relay.d 

OBJS += \
./HARDWARE/RELAY/relay.o 

OBJS__QUOTED += \
"HARDWARE\RELAY\relay.o" 

C_DEPS__QUOTED += \
"HARDWARE\RELAY\relay.d" 

C_SRCS__QUOTED += \
"../HARDWARE/RELAY/relay.c" 


