################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../HARDWARE/KEY/key.c 

C_DEPS += \
./HARDWARE/KEY/key.d 

OBJS += \
./HARDWARE/KEY/key.o 

OBJS__QUOTED += \
"HARDWARE\KEY\key.o" 

C_DEPS__QUOTED += \
"HARDWARE\KEY\key.d" 

C_SRCS__QUOTED += \
"../HARDWARE/KEY/key.c" 


