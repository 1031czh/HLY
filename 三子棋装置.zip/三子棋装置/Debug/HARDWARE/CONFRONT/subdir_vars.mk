################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../HARDWARE/CONFRONT/confront.c 

C_DEPS += \
./HARDWARE/CONFRONT/confront.d 

OBJS += \
./HARDWARE/CONFRONT/confront.o 

OBJS__QUOTED += \
"HARDWARE\CONFRONT\confront.o" 

C_DEPS__QUOTED += \
"HARDWARE\CONFRONT\confront.d" 

C_SRCS__QUOTED += \
"../HARDWARE/CONFRONT/confront.c" 


