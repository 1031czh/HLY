################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../HARDWARE/BEEF/beef.c 

C_DEPS += \
./HARDWARE/BEEF/beef.d 

OBJS += \
./HARDWARE/BEEF/beef.o 

OBJS__QUOTED += \
"HARDWARE\BEEF\beef.o" 

C_DEPS__QUOTED += \
"HARDWARE\BEEF\beef.d" 

C_SRCS__QUOTED += \
"../HARDWARE/BEEF/beef.c" 


