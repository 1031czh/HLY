################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../DELAY/delay.c 

C_DEPS += \
./DELAY/delay.d 

OBJS += \
./DELAY/delay.o 

OBJS__QUOTED += \
"DELAY\delay.o" 

C_DEPS__QUOTED += \
"DELAY\delay.d" 

C_SRCS__QUOTED += \
"../DELAY/delay.c" 


