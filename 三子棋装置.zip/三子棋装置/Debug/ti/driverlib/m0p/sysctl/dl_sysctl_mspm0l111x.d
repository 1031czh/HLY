# FIXED

ti/driverlib/m0p/sysctl/dl_sysctl_mspm0l111x.o: \
 ../ti/driverlib/m0p/sysctl/dl_sysctl_mspm0l111x.c \
 C:/ti/mspm0_sdk_2_10_00_04/source/ti/devices/DeviceFamily.h
C:/ti/mspm0_sdk_2_10_00_04/source/ti/devices/DeviceFamily.h:
