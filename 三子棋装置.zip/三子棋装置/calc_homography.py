import sys

u = [445, 327, 560, 446, 330, 562, 448, 333, 563]
v = [309, 309, 311, 219, 217, 220, 127, 126, 129]
X = [0.0, -3.2, 3.2, 0.0, -3.2, 3.2, 0.0, -3.2, 3.2]
Y = [28.0, 28.0, 28.0, 31.2, 31.2, 31.2, 34.4, 34.4, 34.4]

def solve_linear_system(A, b):
    n = len(A)
    for i in range(n):
        pivot = i
        for j in range(i+1, n):
            if abs(A[j][i]) > abs(A[pivot][i]):
                pivot = j
        A[i], A[pivot] = A[pivot], A[i]
        b[i], b[pivot] = b[pivot], b[i]
        for j in range(i+1, n):
            factor = A[j][i] / A[i][i]
            for k in range(i, n):
                A[j][k] -= factor * A[i][k]
            b[j] -= factor * b[i]
    x = [0] * n
    for i in range(n-1, -1, -1):
        s = sum(A[i][j] * x[j] for j in range(i+1, n))
        x[i] = (b[i] - s) / A[i][i]
    return x

A = []
b = []
for i in range(9):
    A.append([u[i], v[i], 1, 0, 0, 0, -u[i]*X[i], -v[i]*X[i]])
    A.append([0, 0, 0, u[i], v[i], 1, -u[i]*Y[i], -v[i]*Y[i]])
    b.append(X[i])
    b.append(Y[i])

# Since it's overdetermined (18 equations, 8 unknowns), we use pseudo-inverse A^T A x = A^T b
At = [[A[j][i] for j in range(18)] for i in range(8)]
AtA = [[sum(At[i][k] * A[k][j] for k in range(18)) for j in range(8)] for i in range(8)]
Atb = [sum(At[i][k] * b[k] for k in range(18)) for i in range(8)]

h = solve_linear_system(AtA, Atb)
print("Homography Matrix H:")
print("H0 =", h[0])
print("H1 =", h[1])
print("H2 =", h[2])
print("H3 =", h[3])
print("H4 =", h[4])
print("H5 =", h[5])
print("H6 =", h[6])
print("H7 =", h[7])

print("\nVerify:")
for i in range(9):
    w = h[6]*u[i] + h[7]*v[i] + 1.0
    pred_X = (h[0]*u[i] + h[1]*v[i] + h[2]) / w
    pred_Y = (h[3]*u[i] + h[4]*v[i] + h[5]) / w
    print(f"P{i}: Target=({X[i]:.2f}, {Y[i]:.2f}) -> Pred=({pred_X:.2f}, {pred_Y:.2f})  Error=({pred_X-X[i]:.3f}, {pred_Y-Y[i]:.3f})")
