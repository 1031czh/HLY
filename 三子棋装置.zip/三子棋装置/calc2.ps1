$u = @(443, 335, 551, 447, 338, 555, 450, 341, 559)
$v = @(259, 256, 262, 173, 168, 176,  85,  81,  89)
$X = @(0.0, -3.2, 3.2, 0.0, -3.2, 3.2, 0.0, -3.2, 3.2)
$Y = @(28.0, 28.0, 28.0, 31.2, 31.2, 31.2, 34.4, 34.4, 34.4)

$n = $u.Length
$su = 0.0; $sv = 0.0; $su2 = 0.0; $sv2 = 0.0; $suv = 0.0
for ($i=0; $i -lt $n; $i++) {
    $su += $u[$i]; $sv += $v[$i]
    $su2 += $u[$i]*$u[$i]; $sv2 += $v[$i]*$v[$i]
    $suv += $u[$i]*$v[$i]
}

function det3x3($m) {
    return ($m[0][0]*($m[1][1]*$m[2][2] - $m[1][2]*$m[2][1]) -
            $m[0][1]*($m[1][0]*$m[2][2] - $m[1][2]*$m[2][0]) +
            $m[0][2]*($m[1][0]*$m[2][1] - $m[1][1]*$m[2][0]))
}

function solve($t) {
    $st = 0.0; $sut = 0.0; $svt = 0.0
    for ($i=0; $i -lt $n; $i++) {
        $st += $t[$i]; $sut += $u[$i]*$t[$i]; $svt += $v[$i]*$t[$i]
    }
    
    $A = @(
        @($su2, $suv, $su),
        @($suv, $sv2, $sv),
        @($su,  $sv,  $n)
    )
    $detA = det3x3 $A
    
    $Aa = @(
        @($sut, $suv, $su),
        @($svt, $sv2, $sv),
        @($st,  $sv,  $n)
    )
    $Ab = @(
        @($su2, $sut, $su),
        @($suv, $svt, $sv),
        @($su,  $st,  $n)
    )
    $Ac = @(
        @($su2, $suv, $sut),
        @($suv, $sv2, $svt),
        @($su,  $sv,  $st)
    )
    
    $a = (det3x3 $Aa) / $detA
    $b = (det3x3 $Ab) / $detA
    $c = (det3x3 $Ac) / $detA
    return @($a, $b, $c)
}

$resX = solve $X
$resY = solve $Y

Write-Host "X = $($resX[0]) * px + $($resX[1]) * py + $($resX[2])"
Write-Host "Y = $($resY[0]) * px + $($resY[1]) * py + $($resY[2])"
