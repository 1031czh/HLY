
#ifndef DELAY_H_
#define DELAY_H_

/* 延时函数 */
void delay_us(int __us);
void delay_ms(int __ms);

void delay_1us(int __us);
void delay_1ms(int __ms);

#endif /* DELAY_H_ */