#include <ti/driverlib/m0p/dl_interrupt.h>
#include <stdio.h>
#include "ti_msp_dl_config.h"
#include "stepper_motor.h"
#include "uart.h"
#include "delay.h"
#include "relay.h"
#include "oled.h"
#include "key.h"
#include "confront.h"
#include <string.h>
#include "servo.h"

// 电机基础地址
uint8_t motor_addr = 0x01;

#define MODE0_BOARD_COUNT        9
#define MODE0_OUT_MARGIN_CM      4.0f
#define MODE0_OCCUPY_MAX_D2      (4.0f * 4.0f)

static uint8_t Mode0_GetBoardBounds(float *min_x, float *max_x, float *min_y, float *max_y)
{
    if (g_map_rect_count == 0) return 0;

    *min_x = 999.0f;
    *max_x = -999.0f;
    *min_y = 999.0f;
    *max_y = -999.0f;

    for (int j = 0; j < g_map_rect_count; j++) {
        if (g_map_phys[j].x < *min_x) *min_x = g_map_phys[j].x;
        if (g_map_phys[j].x > *max_x) *max_x = g_map_phys[j].x;
        if (g_map_phys[j].y < *min_y) *min_y = g_map_phys[j].y;
        if (g_map_phys[j].y > *max_y) *max_y = g_map_phys[j].y;
    }

    *min_x -= MODE0_OUT_MARGIN_CM; *max_x += MODE0_OUT_MARGIN_CM;
    *min_y -= MODE0_OUT_MARGIN_CM; *max_y += MODE0_OUT_MARGIN_CM;
    return 1;
}

static uint8_t Mode0_FindNearestCell(float x, float y, uint8_t *index)
{
    float best_d2 = MODE0_OCCUPY_MAX_D2;
    uint8_t found = 0;
    uint8_t count = (g_map_rect_count < MODE0_BOARD_COUNT) ? g_map_rect_count : MODE0_BOARD_COUNT;

    for (int i = 0; i < count; i++)
    {
        float dx = x - g_map_phys[i].x;
        float dy = y - g_map_phys[i].y;
        float d2 = dx * dx + dy * dy;
        if (d2 <= best_d2)
        {
            best_d2 = d2;
            *index = (uint8_t)i;
            found = 1;
        }
    }
    return found;
}

static uint8_t Mode0_IsCellOccupied(uint8_t index)
{
    uint8_t cell;
    if (g_map_rect_count == 0 || index >= g_map_rect_count) return 1;

    for (int i = 0; i < g_black_in_blob_count; i++) {
        if (Mode0_FindNearestCell(g_black_in_phys[i].x, g_black_in_phys[i].y, &cell) && cell == index) return 1;
    }
    for (int i = 0; i < g_white_in_blob_count; i++) {
        if (Mode0_FindNearestCell(g_white_in_phys[i].x, g_white_in_phys[i].y, &cell) && cell == index) return 1;
    }
    return 0;
}

static uint8_t Mode0_IsBetterSource(float x, float y, float best_x, float best_y)
{
    if (y < best_y - 0.1f) return 1;
    if (y > best_y + 0.1f) return 0;
    return (x < best_x);
}

static uint8_t Mode0_FindSource(const PhysPoint2D *phys, uint8_t count, float *x, float *y)
{
    float min_x, max_x, min_y, max_y;
    uint8_t found = 0;
    float best_x = 999.0f, best_y = 999.0f;

    if (!Mode0_GetBoardBounds(&min_x, &max_x, &min_y, &max_y)) return 0;

    for (int i = 0; i < count; i++) {
        float px = phys[i].x;
        float py = phys[i].y;

        // 如果这个棋子落在棋盘包围盒内部，说明是视觉将其误判为了“外”，忽略它
        if (px >= min_x && px <= max_x && py >= min_y && py <= max_y) {
            continue;
        }

        if (!found || Mode0_IsBetterSource(px, py, best_x, best_y)) {
            best_x = px;
            best_y = py;
            found = 1;
        }
    }

    if (found) {
        *x = best_x;
        *y = best_y;
    }
    return found;
}

int main(void)
{
    char oled_buf[32]; 

    SYSCFG_DL_init();
    OLED_Init();
    zdt_motor_init();

    // 1. OLED 初始界面
    OLED_Clear();
    OLED_ShowString(0, 0, (uint8_t *)"Mode:0          ", 16);
    OLED_ShowString(0, 2, (uint8_t *)"Pt:--/--        ", 16);
    OLED_ShowString(0, 4, (uint8_t *)"                ", 16);
    OLED_ShowString(0, 6, (uint8_t *)"Color:BLACK     ", 16);

    // 2. 使能电机
    zdt_motor_enable(UART_Left_INST, motor_addr, true);
    zdt_motor_enable(UART_Right_INST, motor_addr, true);
    delay_ms(2000);

    // 3. 上电回零
    zdt_motor_startup_home(UART_Left_INST, UART_Right_INST, motor_addr);

    Relay_OFF(); // 初始关闭吸附，节省能量并防热
    servoInit();

    setServoAngle(-180);  //提高磁铁位置
    // 4. 开启中断（Target + Map 两路 UART）
    NVIC_EnableIRQ(UART_Target_INST_INT_IRQN);
    DL_UART_enableInterrupt(UART_Target_INST, DL_UART_INTERRUPT_RX | 
                                              DL_UART_INTERRUPT_OVERRUN_ERROR | 
                                              DL_UART_INTERRUPT_FRAMING_ERROR | 
                                              DL_UART_INTERRUPT_NOISE_ERROR | 
                                              DL_UART_INTERRUPT_PARITY_ERROR | 
                                              DL_UART_INTERRUPT_BREAK_ERROR);
    NVIC_EnableIRQ(UART_Map_INST_INT_IRQN);
    DL_UART_enableInterrupt(UART_Map_INST, DL_UART_INTERRUPT_RX | 
                                           DL_UART_INTERRUPT_OVERRUN_ERROR | 
                                           DL_UART_INTERRUPT_FRAMING_ERROR | 
                                           DL_UART_INTERRUPT_NOISE_ERROR | 
                                           DL_UART_INTERRUPT_PARITY_ERROR | 
                                           DL_UART_INTERRUPT_BREAK_ERROR);
    Key_Init();
    Confront_Init();
    __enable_irq();
      
    while (1)
    {
        Key_Process();
        Confront_Process();

        static uint32_t oled_reinit_timer = 0;
        oled_reinit_timer++;

        // ===== OLED 自动恢复与重建机制（防电机运行 EMI 干扰死锁或花屏） =====
        if (g_oled_need_reinit || oled_reinit_timer >= 300)
        {
            g_oled_need_reinit = 0;
            oled_reinit_timer = 0;
            OLED_Init(); // 重新复位硬件和初始化配置
            
            // 重新刷新全屏幕的静态信息，恢复显示
            sprintf(oled_buf, "Mode:%d          ", g_current_mode);
            OLED_ShowString(0, 0, (uint8_t *)oled_buf, 16);
            if (g_current_mode == 0)
            {
                if (g_map_rect_count > 0) {
                    sprintf(oled_buf, "Pt:%d/%d        ", g_selected_index + 1, g_map_rect_count);
                } else {
                    sprintf(oled_buf, "Pt:--/--        ");
                }
                OLED_ShowString(0, 2, (uint8_t *)oled_buf, 16);
            }
            
            sprintf(oled_buf, "Color:%-10s", g_piece_color == 0 ? "BLACK" : "WHITE");
            OLED_ShowString(0, 6, (uint8_t *)oled_buf, 16);
        }

        // ===== 模式 0：处理地图数据与选择位置更新 =====
        if (g_current_mode == 0)
        {
            if (g_map_data_ready) g_map_data_ready = 0;
            if (g_target_data_ready) g_target_data_ready = 0;

            // 仅在选择点发生改变或地图点数更新时更新 Row 2 显示，极其节省 CPU 时序
            static uint8_t last_selected_index = 0xFF;
            static uint8_t last_map_rect_count = 0xFF;
            if (g_selected_index != last_selected_index || g_map_rect_count != last_map_rect_count)
            {
                last_selected_index = g_selected_index;
                last_map_rect_count = g_map_rect_count;
                if (g_map_rect_count > 0)
                {
                    sprintf(oled_buf, "Pt:%d/%d        ", g_selected_index + 1, g_map_rect_count);
                }
                else
                {
                    sprintf(oled_buf, "Pt:--/--        ");
                }
                OLED_ShowString(0, 2, (uint8_t *)oled_buf, 16);
            }
        }

        // ===== 模式 0：由按键 2 触发的一键搬运逻辑 =====
        if (g_current_mode == 0 && g_trigger_move)
        {
            g_trigger_move = 0; // 立即清除触发标志

            if (g_map_rect_count == 0 || g_selected_index >= g_map_rect_count)
            {
                OLED_ShowString(0, 4, (uint8_t *)"NO MAP          ", 16);
            }
            else if (Mode0_IsCellOccupied(g_selected_index))
            {
                OLED_ShowString(0, 4, (uint8_t *)"OCCUPIED        ", 16);
                Relay_OFF();
                setServoAngle(-180);
            }
            else
            {
                float source_x = 0.0f, source_y = 0.0f;
                uint8_t found_source = 0;

                if (g_piece_color == 0 && g_black_out_blob_count > 0)
                {
                    found_source = Mode0_FindSource(g_black_out_phys, g_black_out_blob_count, &source_x, &source_y);
                }
                else if (g_piece_color == 1 && g_white_out_blob_count > 0)
                {
                    found_source = Mode0_FindSource(g_white_out_phys, g_white_out_blob_count, &source_x, &source_y);
                }

                if (found_source)
                {
                    float grid_x = g_map_phys[g_selected_index].x;
                    float grid_y = g_map_phys[g_selected_index].y;
                    zdt_fivebar_pick_and_place(UART_Left_INST, UART_Right_INST, motor_addr,
                                               source_x, source_y, grid_x, grid_y);
                    OLED_ShowString(0, 4, (uint8_t *)"                ", 16);
                }
                else
                {
                    OLED_ShowString(0, 4, (uint8_t *)"NO SOURCE       ", 16);
                    Relay_OFF();
                    setServoAngle(-180);
                }
            }
        }

        // 维持静态对比更新，彻底杜绝闪烁和时序抢占
        static char last_row0[32] = "";
        sprintf(oled_buf, "Mode:%d          ", g_current_mode);
        if (strcmp(last_row0, oled_buf) != 0)
        {
            strcpy(last_row0, oled_buf);
            OLED_ShowString(0, 0, (uint8_t *)oled_buf, 16);
        }

        static char last_row6[32] = "";
        sprintf(oled_buf, "Color:%-10s", g_piece_color == 0 ? "BLACK" : "WHITE");
        if (strcmp(last_row6, oled_buf) != 0)
        {
            strcpy(last_row6, oled_buf);
            OLED_ShowString(0, 6, (uint8_t *)oled_buf, 16);
        }

        // (Removed blind UART flag clearing to prevent packet loss race condition)

        // 维持主循环大约 10ms 的节拍，以方便按键消抖和长按计数
        delay_ms(10);
    }
}
