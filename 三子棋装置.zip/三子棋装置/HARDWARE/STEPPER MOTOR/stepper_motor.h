#ifndef ZDT_MOTOR_H
#define ZDT_MOTOR_H

#include <stdint.h>
#include <stdbool.h>
#include <ti/devices/msp/msp.h> // 引入包含 UART_Regs 结构体定义的头文件

void zdt_motor_init(void);

void zdt_motor_enable(UART_Regs *uart_inst, uint8_t addr, bool enable);

void zdt_motor_set_speed(UART_Regs *uart_inst, uint8_t addr, uint8_t dir, uint16_t rpm, uint8_t acc);

void zdt_motor_move_rel(UART_Regs *uart_inst, uint8_t addr, uint8_t dir, uint16_t speed, uint8_t acc, uint32_t pulses);

void zdt_motor_move_abs(UART_Regs *uart_inst, uint8_t addr, uint8_t dir, uint16_t speed, uint8_t acc, uint32_t pulses);

void zdt_motor_move_angle(UART_Regs *uart_inst, uint8_t addr, uint8_t dir, uint16_t speed, uint8_t acc, uint16_t angle, bool is_abs);

void zdt_motor_reset_position(UART_Regs *uart_inst, uint8_t addr);

void zdt_motor_stop(UART_Regs *uart_inst, uint8_t addr);

/**
 * @brief 将当前位置设为零点并保存到驱动器 Flash（断电不丢失）
 * @note  调用一次即可永久生效，无需每次上电都调用
 */
void zdt_motor_set_zero(UART_Regs *uart_inst, uint8_t addr);

/**
 * @brief 触发回零动作（单圈就近回零），电机将运动到之前保存的零点位置
 * @note  每次上电后调用此函数，即可回到之前 set_zero 保存的位置
 */
void zdt_motor_go_zero(UART_Regs *uart_inst, uint8_t addr);

/**
 * @brief 上电启动回零流程（封装了按键检测 + 设零点/回零 + OLED 提示）
 * @note  在 main 中电机使能后直接调用即可
 */
void zdt_motor_startup_home(UART_Regs *uart_left, UART_Regs *uart_right, uint8_t addr);

/**
 * @brief 五连杆逆运动学：控制电机使末端到达指定物理坐标 (cm)
 * @param x_cm 目标 X 坐标（原点 = 两电机轴心距中点）
 * @param y_cm 目标 Y 坐标
 */
void zdt_fivebar_goto(UART_Regs *uart_left, UART_Regs *uart_right, uint8_t addr, float x_cm, float y_cm);

uint8_t zdt_fivebar_move_to(UART_Regs *uart_left, UART_Regs *uart_right, uint8_t addr, float x_cm, float y_cm);
uint8_t zdt_fivebar_pick_at(UART_Regs *uart_left, UART_Regs *uart_right, uint8_t addr, float x_cm, float y_cm);
uint8_t zdt_fivebar_place_at(UART_Regs *uart_left, UART_Regs *uart_right, uint8_t addr, float x_cm, float y_cm);
uint8_t zdt_fivebar_pick_and_place(UART_Regs *uart_left, UART_Regs *uart_right, uint8_t addr,
                                   float src_x_cm, float src_y_cm, float dst_x_cm, float dst_y_cm);

void zdt_fivebar_go_zero(UART_Regs *uart_left, UART_Regs *uart_right, uint8_t addr);

extern volatile uint32_t g_goto_count;

#endif /* ZDT_MOTOR_H */


