#include "stepper_motor.h"
#include "ti_msp_dl_config.h"
#include "delay.h"
#include "oled.h"
#include <math.h>
#include "relay.h"
#include "servo.h"

#include <ti/driverlib/m0p/dl_core.h>
#include <ti/driverlib/driverlib.h>

#define ZDT_CHECKSUM    0x6B

volatile uint32_t g_goto_count = 0;


/**
 * @brief 通过指定串口发送一个字节
 */
static void zdt_uart_send_byte(UART_Regs *uart_inst, uint8_t data)
{
    while (DL_UART_isTXFIFOFull(uart_inst));   
    // 将数据写入指定的发送寄存器
    DL_UART_Main_transmitData(uart_inst, data);
}

/**
 * @brief 发送多字节数组到指定串口
 */
static void zdt_uart_send_array(UART_Regs *uart_inst, const uint8_t *data, uint16_t len)
{
    for (uint16_t i = 0; i < len; i++) {
        zdt_uart_send_byte(uart_inst, data[i]);
    }
    
    // 确保整包数据在物理上完全发送完毕
    while (DL_UART_isBusy(uart_inst));
}

void zdt_motor_init(void)
{
    // 串口硬件已由主函数中的 SYSCFG_DL_init() 初始化完毕，此处留空
}

void zdt_motor_enable(UART_Regs *uart_inst, uint8_t addr, bool enable)
{
    uint8_t cmd[6];
    cmd[0] = addr;
    cmd[1] = 0xF3;
    cmd[2] = 0xAB;
    cmd[3] = enable ? 0x01 : 0x00;
    cmd[4] = 0x00;          // 多机同步标志：不启用
    cmd[5] = ZDT_CHECKSUM;

    zdt_uart_send_array(uart_inst, cmd, 6);
}

void zdt_motor_set_speed(UART_Regs *uart_inst, uint8_t addr, uint8_t dir, uint16_t rpm, uint8_t acc)
{
    uint8_t cmd[8];
    cmd[0] = addr;
    cmd[1] = 0xF6;
    cmd[2] = dir;                   // 方向
    cmd[3] = (rpm >> 8) & 0xFF;     // 速度高字节
    cmd[4] = rpm & 0xFF;            // 速度低字节
    cmd[5] = acc;                   // 加速度档位
    cmd[6] = 0x00;                  // 多机同步标志：不启用
    cmd[7] = ZDT_CHECKSUM;

    zdt_uart_send_array(uart_inst, cmd, 8);
}

void zdt_motor_move_rel(UART_Regs *uart_inst, uint8_t addr, uint8_t dir, uint16_t speed, uint8_t acc, uint32_t pulses)
{
    uint8_t cmd[13];
    cmd[0]  = addr;
    cmd[1]  = 0xFD;
    cmd[2]  = dir;                      // 方向
    cmd[3]  = (speed >> 8) & 0xFF;      // 速度高字节
    cmd[4]  = speed & 0xFF;             // 速度低字节
    cmd[5]  = acc;                      // 加速度档位
    cmd[6]  = (pulses >> 24) & 0xFF;    // 脉冲数高字节
    cmd[7]  = (pulses >> 16) & 0xFF;
    cmd[8]  = (pulses >> 8)  & 0xFF;
    cmd[9]  = pulses & 0xFF;            // 脉冲数低字节
    cmd[10] = 0x00;                     // 相对位置模式
    cmd[11] = 0x00;                     // 多机同步标志：不启用
    cmd[12] = ZDT_CHECKSUM;

    zdt_uart_send_array(uart_inst, cmd, 13);
}

void zdt_motor_move_abs(UART_Regs *uart_inst, uint8_t addr, uint8_t dir, uint16_t speed, uint8_t acc, uint32_t pulses)
{
    uint8_t cmd[13];
    cmd[0]  = addr;
    cmd[1]  = 0xFD;
    cmd[2]  = dir;                      // 方向
    cmd[3]  = (speed >> 8) & 0xFF;      // 速度高字节
    cmd[4]  = speed & 0xFF;             // 速度低字节
    cmd[5]  = acc;                      // 加速度档位
    cmd[6]  = (pulses >> 24) & 0xFF;    // 脉冲数高字节
    cmd[7]  = (pulses >> 16) & 0xFF;
    cmd[8]  = (pulses >> 8)  & 0xFF;
    cmd[9]  = pulses & 0xFF;            // 脉冲数低字节
    cmd[10] = 0x01;                     // 绝对位置模式
    cmd[11] = 0x00;                     // 多机同步标志：不启用
    cmd[12] = ZDT_CHECKSUM;

    zdt_uart_send_array(uart_inst, cmd, 13);
}

void zdt_motor_move_angle(UART_Regs *uart_inst, uint8_t addr, uint8_t dir, uint16_t speed, uint8_t acc, uint16_t angle, bool is_abs)
{
    // 在本驱动配置下，3200 脉冲代表转动一圈（360度）
    uint32_t pulses = (uint32_t)angle * 3200 / 360;
    if (is_abs) {
        zdt_motor_move_abs(uart_inst, addr, dir, speed, acc, pulses);
    } else {
        zdt_motor_move_rel(uart_inst, addr, dir, speed, acc, pulses);
    }
}

void zdt_motor_reset_position(UART_Regs *uart_inst, uint8_t addr)
{
    uint8_t cmd[4];
    cmd[0] = addr;
    cmd[1] = 0x0A;
    cmd[2] = 0x6D;
    cmd[3] = ZDT_CHECKSUM;

    zdt_uart_send_array(uart_inst, cmd, 4);
}

void zdt_motor_stop(UART_Regs *uart_inst, uint8_t addr)
{
    uint8_t cmd[5];
    cmd[0] = addr;
    cmd[1] = 0xFE;
    cmd[2] = 0x98;
    cmd[3] = 0x00;          // 多机同步标志：不启用
    cmd[4] = ZDT_CHECKSUM;

    zdt_uart_send_array(uart_inst, cmd, 5);
}

void zdt_motor_set_zero(UART_Regs *uart_inst, uint8_t addr)
{
    // 协议：地址 + 0x93 + 0x88 + 存储标志 + 校验
    // 存储标志 0x01 = 保存到 Flash（断电不丢失）
    uint8_t cmd[5];
    cmd[0] = addr;
    cmd[1] = 0x93;
    cmd[2] = 0x88;
    cmd[3] = 0x01;          // 保存到 Flash
    cmd[4] = ZDT_CHECKSUM;

    zdt_uart_send_array(uart_inst, cmd, 5);
    g_goto_count = 0; // 重置移动次数计数
}

void zdt_motor_go_zero(UART_Regs *uart_inst, uint8_t addr)
{
    // 协议：地址 + 0x9A + 回零模式 + 多机同步标志 + 校验
    // 回零模式 0x00 = 单圈就近回零（走最近的路径回到零点）
    uint8_t cmd[5];
    cmd[0] = addr;
    cmd[1] = 0x9A;
    cmd[2] = 0x00;          // 回零模式：单圈就近回零
    cmd[3] = 0x00;          // 多机同步标志：不启用
    cmd[4] = ZDT_CHECKSUM;

    zdt_uart_send_array(uart_inst, cmd, 5);
}

void zdt_motor_startup_home(UART_Regs *uart_left, UART_Regs *uart_right, uint8_t addr)
{
    // 检测按键3（PA17）：若上电时按住，则将当前位置设为新零点；否则执行回零
    if (DL_GPIO_readPins(GPIOA, GPIO_Key_PIN_3_PIN) == 0)
    {
        // 按键3被按住 → 设置当前位置为新零点
        zdt_motor_set_zero(uart_left, addr);
        zdt_motor_set_zero(uart_right, addr);
        OLED_ShowString(0, 2, (uint8_t *)"Zero Saved!  ", 16);
        delay_ms(1000);
    }
    else
    {
        // 按键3未被按住 → 正常回零
        zdt_motor_go_zero(uart_left, addr);
        zdt_motor_go_zero(uart_right, addr);
        delay_ms(2000);
    }
    g_goto_count = 0; // 重置移动次数计数
}

// ===== 五连杆逆运动学 =====
#define FIVEBAR_L1               16.5f   // 主臂长 (cm)
#define FIVEBAR_L2               25.0f   // 长臂长 (cm)
#define FIVEBAR_D                5.0f    // 轴心距 (cm)
#define FIVEBAR_ZERO_X           0.0f    // 零点标定时末端 X (cm)
#define FIVEBAR_ZERO_Y           22.7f   // 零点标定时末端 Y (cm)
#define FIVEBAR_SPEED            150     // 运动速度 (RPM)
#define FIVEBAR_ACC              5       // 加速度档位
#define FIVEBAR_MOVE_MIN_WAIT_MS 2200    // 普通运动最小等待时间
#define FIVEBAR_HOME_WAIT_MS     3200    // 投放后回零等待时间
#define FIVEBAR_SETTLE_WAIT_MS   1200    // 按行程估算后的额外稳定时间
#define FIVEBAR_SERVO_WAIT_MS    1000    // 舵机下放/抬起等待时间
#define FIVEBAR_RELAY_WAIT_MS    500     // 吸附/释放稳定等待时间

// --- 调试参数（方向和细分）---
#define FIVEBAR_PULSES_PER_REV   3200.0f // 电机旋转一圈（360度）所需的脉冲数（与电机驱动器细分设置一致，若位移偏小可尝试设为 6400.0f 等）
#define LEFT_MOTOR_DIR_INV       0       // 左电机方向反向标志（0:不反向, 1:反向）
#define RIGHT_MOTOR_DIR_INV      0       // 右电机方向反向标志（0:不反向, 1:反向）
#define FIVEBAR_ELBOW_OUTWARDS   1       // 肘关节弯折方向（1:朝外侧展开, 0:朝内侧折）

// --- Y 轴左侧补偿 (当 X < 0 时) ---
#define FIVEBAR_Y_COMP_REF       22.7f   // Y 轴补偿参考点 (cm)，Y 低于此值不补偿
#define FIVEBAR_Y_COMP_K1_LEFT   0.0f   // 左侧一次补偿系数
#define FIVEBAR_Y_COMP_K2_LEFT   0.0f // 左侧二次补偿系数

// --- Y 轴右侧补偿 (当 X >= 0 时) ---
// 针对左右机械结构不对称导致右侧单独存在偏差的问题
#define FIVEBAR_Y_COMP_K1_RIGHT  0.0f   // 右侧一次补偿系数 (偏近则改大，偏远则改小)
#define FIVEBAR_Y_COMP_K2_RIGHT  0.0f // 右侧二次补偿系数

// --- X 轴补偿 ---
// 解决两侧 X 偏移（不够够头/未到位问题）以及 X 轴上的非线性发散（内侧准外侧偏，或外侧准内侧偏）
// 公式: x_comp = x + x * K1 + x * |x| * K2
#define FIVEBAR_X_COMP_K1_LEFT   0.0f    // 左侧一次线性系数
#define FIVEBAR_X_COMP_K2_LEFT   0.0f      // 左侧二次非线性系数 (专门解决"内侧准远端偏"的问题)
#define FIVEBAR_X_COMP_K1_RIGHT  0.0f      // 右侧一次线性系数
#define FIVEBAR_X_COMP_K2_RIGHT  0.0f      // 右侧二次非线性系数

// 计算单个电机的角度（弧度）
// is_left: 1=左电机(-d/2,0)  0=右电机(+d/2,0)
static float fivebar_ik_angle(float x, float y, int is_left)
{
    float half_d = FIVEBAR_D / 2.0f;
    float dx = is_left ? (x + half_d) : (x - half_d);
    float r = sqrtf(dx * dx + y * y);

    float cos_alpha = (FIVEBAR_L1 * FIVEBAR_L1 + r * r - FIVEBAR_L2 * FIVEBAR_L2)
                      / (2.0f * FIVEBAR_L1 * r);
    // 限幅防止 acos 异常
    if (cos_alpha > 1.0f) cos_alpha = 1.0f;
    if (cos_alpha < -1.0f) cos_alpha = -1.0f;

    float alpha = acosf(cos_alpha);
    float phi = atan2f(y, dx);

    if (FIVEBAR_ELBOW_OUTWARDS) {
        // 肘关节向外折：左臂角度为 phi + alpha，右臂角度为 phi - alpha
        return is_left ? (phi + alpha) : (phi - alpha);
    } else {
        // 肘关节向内折：左臂角度为 phi - alpha，右臂角度为 phi + alpha
        return is_left ? (phi - alpha) : (phi + alpha);
    }
}

static uint8_t fivebar_prepare_target(float *x_cm, float *y_cm)
{
    float dy = *y_cm - FIVEBAR_Y_COMP_REF;
    float x_sq = (*x_cm) * fabsf(*x_cm); // 保留符号的平方项 x * |x|

    // X 轴分域独立补偿：支持线性和非线性二次补偿
    if (*x_cm < 0.0f) {
        *x_cm = *x_cm + *x_cm * FIVEBAR_X_COMP_K1_LEFT + x_sq * FIVEBAR_X_COMP_K2_LEFT;
    } else {
        *x_cm = *x_cm + *x_cm * FIVEBAR_X_COMP_K1_RIGHT + x_sq * FIVEBAR_X_COMP_K2_RIGHT;
    }

    // Y 轴补偿：修正关节摩擦等导致的系统性误差
    if (dy > 0.0f) {
        // 仅对超出参考点的部分进行补偿（参考点以下的第一排精度已经很好）
        if (*x_cm < 0.0f) {
            *y_cm = *y_cm + dy * FIVEBAR_Y_COMP_K1_LEFT + dy * dy * FIVEBAR_Y_COMP_K2_LEFT;
        } else {
            *y_cm = *y_cm + dy * FIVEBAR_Y_COMP_K1_RIGHT + dy * dy * FIVEBAR_Y_COMP_K2_RIGHT;
        }
    }

    // 基础可达性保护，避免不可达/异常坐标被夹角后仍发送给电机
    float half_d = FIVEBAR_D / 2.0f;
    float min_r = fabsf(FIVEBAR_L2 - FIVEBAR_L1);
    float max_r = FIVEBAR_L1 + FIVEBAR_L2;
    float dx_l = *x_cm + half_d;
    float dx_r = *x_cm - half_d;
    float r_l = sqrtf(dx_l * dx_l + *y_cm * *y_cm);
    float r_r = sqrtf(dx_r * dx_r + *y_cm * *y_cm);

    if (r_l < min_r || r_l > max_r || r_r < min_r || r_r > max_r) {
        return 0;
    }
    return 1;
}

static uint16_t fivebar_calc_wait_ms(uint32_t pulses_l, uint32_t pulses_r)
{
    uint32_t max_pulses = (pulses_l > pulses_r) ? pulses_l : pulses_r;
    uint32_t wait_ms;

    // 估算 ZDT 电机在当前 rpm 下走完最大脉冲量所需时间，并额外留出加减速/负载余量。
    // 原来固定 1500/1800ms，远距离移动时可能还没到位就开始下放落子。
    wait_ms = (uint32_t)((uint64_t)max_pulses * 60000u / ((uint32_t)FIVEBAR_SPEED * FIVEBAR_PULSES_PER_REV));
    wait_ms += FIVEBAR_SETTLE_WAIT_MS;
    if (wait_ms < FIVEBAR_MOVE_MIN_WAIT_MS) wait_ms = FIVEBAR_MOVE_MIN_WAIT_MS;
    if (wait_ms > 6000u) wait_ms = 6000u;
    return (uint16_t)wait_ms;
}

uint8_t zdt_fivebar_move_to(UART_Regs *uart_left, UART_Regs *uart_right, uint8_t addr, float x_cm, float y_cm)
{
    if (!fivebar_prepare_target(&x_cm, &y_cm)) {
        Relay_OFF();
        setServoAngle(-180);
        return 0;
    }

    // 1. 计算零点位置的电机角度
    float theta_L_zero = fivebar_ik_angle(FIVEBAR_ZERO_X, FIVEBAR_ZERO_Y, 1);
    float theta_R_zero = fivebar_ik_angle(FIVEBAR_ZERO_X, FIVEBAR_ZERO_Y, 0);

    // 2. 计算目标位置的电机角度
    float theta_L_target = fivebar_ik_angle(x_cm, y_cm, 1);
    float theta_R_target = fivebar_ik_angle(x_cm, y_cm, 0);

    // 3. 角度差（相对于零点）
    float delta_L = theta_L_target - theta_L_zero;
    float delta_R = theta_R_target - theta_R_zero;

    // 4. 转换为脉冲数（基于定义的脉冲数/圈）
    uint32_t pulses_L = (uint32_t)(fabsf(delta_L) * FIVEBAR_PULSES_PER_REV / (2.0f * 3.14159265f) + 0.5f);
    uint32_t pulses_R = (uint32_t)(fabsf(delta_R) * FIVEBAR_PULSES_PER_REV / (2.0f * 3.14159265f) + 0.5f);

    // 5. 确定方向：ZDT 绝对位置协议中，0x00 表示正位置，0x01 表示负位置
    uint8_t dir_L_base = (delta_L >= 0) ? 0x00 : 0x01;
    uint8_t dir_R_base = (delta_R >= 0) ? 0x00 : 0x01;

    // 根据反向标志进行翻转（0x00 与 0x01 互相翻转可以用 1 - dir）
    uint8_t dir_L = LEFT_MOTOR_DIR_INV ? (1 - dir_L_base) : dir_L_base;
    uint8_t dir_R = RIGHT_MOTOR_DIR_INV ? (1 - dir_R_base) : dir_R_base;

    // 6. 发送绝对位置命令
    zdt_motor_move_abs(uart_left,  addr, dir_L, FIVEBAR_SPEED, FIVEBAR_ACC, pulses_L);
    zdt_motor_move_abs(uart_right, addr, dir_R, FIVEBAR_SPEED, FIVEBAR_ACC, pulses_R);

    delay_ms(fivebar_calc_wait_ms(pulses_L, pulses_R));
    return 1;
}

uint8_t zdt_fivebar_pick_at(UART_Regs *uart_left, UART_Regs *uart_right, uint8_t addr, float x_cm, float y_cm)
{
    if (!zdt_fivebar_move_to(uart_left, uart_right, addr, x_cm, y_cm)) {
        return 0;
    }

    g_goto_count++;
    setServoAngle(0);
    delay_ms(FIVEBAR_SERVO_WAIT_MS);
    Relay_ON();
    delay_ms(FIVEBAR_RELAY_WAIT_MS);
    setServoAngle(-180);
    delay_ms(FIVEBAR_SERVO_WAIT_MS);
    return 1;
}

uint8_t zdt_fivebar_place_at(UART_Regs *uart_left, UART_Regs *uart_right, uint8_t addr, float x_cm, float y_cm)
{
    if (!zdt_fivebar_move_to(uart_left, uart_right, addr, x_cm, y_cm)) {
        return 0;
    }

    g_goto_count++;
    setServoAngle(-80);
    delay_ms(FIVEBAR_SERVO_WAIT_MS);
    Relay_OFF();
    delay_ms(FIVEBAR_RELAY_WAIT_MS);
    setServoAngle(-180);
    delay_ms(FIVEBAR_SERVO_WAIT_MS);

    zdt_fivebar_go_zero(uart_left, uart_right, addr);
    delay_ms(FIVEBAR_HOME_WAIT_MS);
    return 1;
}

uint8_t zdt_fivebar_pick_and_place(UART_Regs *uart_left, UART_Regs *uart_right, uint8_t addr,
                                   float src_x_cm, float src_y_cm, float dst_x_cm, float dst_y_cm)
{
    float check_x = src_x_cm;
    float check_y = src_y_cm;
    if (!fivebar_prepare_target(&check_x, &check_y)) {
        Relay_OFF();
        setServoAngle(-180);
        return 0;
    }

    check_x = dst_x_cm;
    check_y = dst_y_cm;
    if (!fivebar_prepare_target(&check_x, &check_y)) {
        Relay_OFF();
        setServoAngle(-180);
        return 0;
    }

    if (!zdt_fivebar_pick_at(uart_left, uart_right, addr, src_x_cm, src_y_cm)) {
        return 0;
    }
    return zdt_fivebar_place_at(uart_left, uart_right, addr, dst_x_cm, dst_y_cm);
}

void zdt_fivebar_goto(UART_Regs *uart_left, UART_Regs *uart_right, uint8_t addr, float x_cm, float y_cm)
{
    // 兼容旧接口：仍按奇偶次数执行抓取/投放；新业务代码应使用显式 pick/place 接口。
    if ((g_goto_count % 2) == 0) {
        zdt_fivebar_pick_at(uart_left, uart_right, addr, x_cm, y_cm);
    } else {
        zdt_fivebar_place_at(uart_left, uart_right, addr, x_cm, y_cm);
    }
}

void zdt_fivebar_go_zero(UART_Regs *uart_left, UART_Regs *uart_right, uint8_t addr)
{
    zdt_motor_move_abs(uart_left,  addr, 0x00, FIVEBAR_SPEED, FIVEBAR_ACC, 0);
    zdt_motor_move_abs(uart_right, addr, 0x00, FIVEBAR_SPEED, FIVEBAR_ACC, 0);
}

