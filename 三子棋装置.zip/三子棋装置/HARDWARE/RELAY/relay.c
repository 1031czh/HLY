#include "ti_msp_dl_config.h"
#include "relay.h"
#include "delay.h"


//高电平com与no导通，nc为常闭触点

void Relay_ON(void)
{
 DL_GPIO_setPins(Relay_PORT, Relay_PIN_0_PIN); 
}

void Relay_OFF(void)
{
  
  DL_GPIO_clearPins(Relay_PORT, Relay_PIN_0_PIN);
}
