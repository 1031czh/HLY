#ifndef RELAY_H
#define RELAY_H



void Relay_ON(void);
void Relay_OFF(void);


#endif




