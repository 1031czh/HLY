#include "ti_msp_dl_config.h"
#include "delay.h"
#include "beef.h"

void Beef_set(void)
{
#if (USE_BUZZER == 1)
    DL_GPIO_setPins(GPIO_Beef_PORT, GPIO_Beef_PIN_4_PIN); 
#endif
}

void Beef_Reset(void)
{
#if (USE_BUZZER == 1)
    DL_GPIO_clearPins(GPIO_Beef_PORT, GPIO_Beef_PIN_4_PIN);
#endif
}

void Beef_ON(void)
{
    Beef_set();
    delay_ms(100); // 50ms 脆鸣，极小程度阻塞，防串口溢出
    Beef_Reset();
}

