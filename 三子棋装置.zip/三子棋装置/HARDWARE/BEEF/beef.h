#ifndef BEEF_H_
#define BEEF_H_

// 开启/关闭蜂鸣器物理引脚驱动
// 0: 关闭（防止蜂鸣器直驱电流过大，拉垮电源电压导致 SPI/OLED 死机卡屏）
// 1: 开启（如果您的开发板上有三极管等放大驱动电路）
#define USE_BUZZER    1

void Beef_ON(void);
void Beef_set(void);
void Beef_Reset(void);

#endif
