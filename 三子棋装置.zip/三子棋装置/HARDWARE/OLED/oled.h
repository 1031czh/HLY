#ifndef __OLED_H
#define __OLED_H

#include "ti_msp_dl_config.h"

// ---- 根据你最新生成的复合引脚组 GPIO_OLED 宏定义进行匹配 ----

// CS 片选引脚 (GPIOA.2)
#define OLED_CS_CLR()    DL_GPIO_clearPins(Relay_PORT, GPIO_OLED_PIN_CS_PIN)
#define OLED_CS_SET()    DL_GPIO_setPins(Relay_PORT, GPIO_OLED_PIN_CS_PIN)

// RES 复位引脚 (GPIOA.3)
#define OLED_RES_CLR()   DL_GPIO_clearPins(GPIO_OLED_PIN_RES_PORT, GPIO_OLED_PIN_RES_PIN)
#define OLED_RES_SET()   DL_GPIO_setPins(GPIO_OLED_PIN_RES_PORT, GPIO_OLED_PIN_RES_PIN)

// DC 数据/命令选择引脚 (GPIOA.7)
#define OLED_DC_CLR()    DL_GPIO_clearPins(Relay_PORT, GPIO_OLED_PIN_DC_PIN)
#define OLED_DC_SET()    DL_GPIO_setPins(Relay_PORT, GPIO_OLED_PIN_DC_PIN)

// ---- OLED 控制指令宏 ----
#define OLED_CMD  0    // 写命令
#define OLED_DATA 1    // 写数据

// ---- 核心功能函数声明 ----
void OLED_Init(void);
void OLED_Clear(void);
void OLED_Display_On(void);
void OLED_Display_Off(void);
void OLED_Set_Pos(uint8_t x, uint8_t y);
void OLED_ShowChar(uint8_t x, uint8_t y, uint8_t chr, uint8_t size1);
void OLED_ShowString(uint8_t x, uint8_t y, uint8_t *chr, uint8_t size1);

extern volatile uint8_t g_oled_need_reinit;

#endif

