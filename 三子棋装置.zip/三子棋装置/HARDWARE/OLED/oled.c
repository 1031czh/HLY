#include "oled.h"
#include "oled_font.h"

volatile uint8_t g_oled_need_reinit = 0;

// 使用硬件 SPI 外设控制函数，带超时防死锁保护，匹配最新的宏 OLED_INST
static void SPI_WriteByte(uint8_t data)
{
    uint32_t timeout = 50000;
    // 等待发送 FIFO 有空闲空间，如果电磁干扰导致SPI锁死，超时退出
    while (DL_SPI_isTXFIFOFull(OLED_INST) && timeout > 0) {
        timeout--;
    }
    if (timeout == 0) {
        g_oled_need_reinit = 1;
        return;
    }
    
    // 写入数据到 SPI 发送寄存器
    DL_SPI_transmitData8(OLED_INST, data);
    
    // 等待传输彻底完成，带超时防护
    timeout = 50000;
    while (DL_SPI_isBusy(OLED_INST) && timeout > 0) {
        timeout--;
    }
    if (timeout == 0) {
        g_oled_need_reinit = 1;
    }
}

// 向 OLED 写入一个字节（命令或数据）
void OLED_WR_Byte(uint8_t dat, uint8_t cmd)
{
    if(cmd) {
        OLED_DC_SET(); // 写数据
    } else {
        OLED_DC_CLR(); // 写命令
    }
    
    OLED_CS_CLR();   // 拉低片选，开始传输
    SPI_WriteByte(dat);
    OLED_CS_SET();   // 拉高片选，结束传输
    OLED_DC_SET();
}

// 设置光标坐标
void OLED_Set_Pos(uint8_t x, uint8_t y)
{
    OLED_WR_Byte(0xb0 + y, OLED_CMD);                 // 设置页地址（0~7）
    OLED_WR_Byte(((x & 0xf0) >> 4) | 0x10, OLED_CMD); // 设置列地址高4位
    OLED_WR_Byte((x & 0x0f), OLED_CMD);                // 设置列地址低4位
}

// 开启 OLED 显示
void OLED_Display_On(void)
{
    OLED_WR_Byte(0X8D, OLED_CMD); // 电荷泵命令
    OLED_WR_Byte(0X14, OLED_CMD); // 开启电荷泵
    OLED_WR_Byte(0XAF, OLED_CMD); // OLED 唤醒
}

// 关闭 OLED 显示（休眠，节能）
void OLED_Display_Off(void)
{
    OLED_WR_Byte(0X8D, OLED_CMD); // 电荷泵命令
    OLED_WR_Byte(0X10, OLED_CMD); // 关闭电荷泵
    OLED_WR_Byte(0XAE, OLED_CMD); // OLED 休眠
}

// 清屏函数
void OLED_Clear(void)
{
    uint8_t i, n;
    for(i = 0; i < 8; i++)
    {
        OLED_WR_Byte(0xb0 + i, OLED_CMD); // 设置页地址
        OLED_WR_Byte(0x00, OLED_CMD);     // 设置列低地址
        OLED_WR_Byte(0x10, OLED_CMD);     // 设置列高地址
        for(n = 0; n < 128; n++) {
            OLED_WR_Byte(0, OLED_DATA);   // 全填 0 清屏
        }
    }
}

// 在指定位置显示一个字符 (基于您的 8x16 规格字模库)
void OLED_ShowChar(uint8_t x, uint8_t y, uint8_t chr, uint8_t size1)
{
    uint8_t c = 0, i = 0;
    c = chr - ' '; // 得到相对空格的偏移量
    if(x > 128 - 8) {
        x = 0; y = y + 2;
    }
    
    if(size1 == 16)
    {
        // 写上半部分
        OLED_Set_Pos(x, y);
        for(i = 0; i < 8; i++) {
            OLED_WR_Byte(OLED_F8x16[c][i], OLED_DATA);
        }
        // 写下半部分
        OLED_Set_Pos(x, y + 1);
        for(i = 0; i < 8; i++) {
            OLED_WR_Byte(OLED_F8x16[c][i + 8], OLED_DATA);
        }
    }
}

// 显示字符串
void OLED_ShowString(uint8_t x, uint8_t y, uint8_t *chr, uint8_t size1)
{
    uint8_t j = 0;
    while (chr[j] != '\0')
    {
        OLED_ShowChar(x, y, chr[j], size1);
        x += 8;
        if(x > 120) {
            x = 0; y += 2;
        }
        j++;
    }
}

// OLED 初始化
void OLED_Init(void)
{
    // 如果 SPI 外设由于大电流干扰陷入死锁，重置并重新初始化该外设
    DL_SPI_reset(OLED_INST);
    DL_SPI_enablePower(OLED_INST);
    SYSCFG_DL_OLED_init(); // 调用 SysConfig 生成的代码重建 SPI 状态机

    // 硬件复位时序
    OLED_RES_SET();
    delay_cycles(100000); 
    OLED_RES_CLR();
    delay_cycles(200000); // 拉低复位
    OLED_RES_SET();       // 复位结束
    delay_cycles(100000);

    // SSD1306 初始化命令序列
    OLED_WR_Byte(0xAE, OLED_CMD); // 关闭显示
    OLED_WR_Byte(0x00, OLED_CMD); // 设置低列地址
    OLED_WR_Byte(0x10, OLED_CMD); // 设置高列地址
    OLED_WR_Byte(0x40, OLED_CMD); // 设置起始行地址
    OLED_WR_Byte(0x81, OLED_CMD); // 对比度设置
    OLED_WR_Byte(0xCF, OLED_CMD); // 亮度调节 (0x00~0xFF)
    OLED_WR_Byte(0xA1, OLED_CMD); // 设置左右方向 (0xA1 正常)
    OLED_WR_Byte(0xC8, OLED_CMD); // 设置上下方向 (0xC8 正常)
    OLED_WR_Byte(0xA6, OLED_CMD); // 正常显示
    OLED_WR_Byte(0xA8, OLED_CMD); // 设置多路复率
    OLED_WR_Byte(0x3F, OLED_CMD); // 1/64 Duty
    OLED_WR_Byte(0xD3, OLED_CMD); // 设置显示偏移
    OLED_WR_Byte(0x00, OLED_CMD);
    OLED_WR_Byte(0xD5, OLED_CMD); // 设置时钟分频
    OLED_WR_Byte(0x80, OLED_CMD);
    OLED_WR_Byte(0xD9, OLED_CMD); // 设置预充电周期
    OLED_WR_Byte(0xF1, OLED_CMD);
    OLED_WR_Byte(0xDA, OLED_CMD); // 设置引脚配置
    OLED_WR_Byte(0x12, OLED_CMD);
    OLED_WR_Byte(0xDB, OLED_CMD); // 设置 VCOMH
    OLED_WR_Byte(0x40, OLED_CMD);
    OLED_WR_Byte(0x8D, OLED_CMD); // 电荷泵设置
    OLED_WR_Byte(0x14, OLED_CMD); // 开启电荷泵
    OLED_WR_Byte(0xAF, OLED_CMD); // 开启 OLED 显示
    
    OLED_Clear(); // 清屏
}


