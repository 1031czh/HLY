#ifndef HARDWARE_CONFRONT_CONFRONT_H_
#define HARDWARE_CONFRONT_CONFRONT_H_

void Confront_Init(void);
void Confront_Reset(void);
void Confront_Process(void);

#endif /* HARDWARE_CONFRONT_CONFRONT_H_ */
