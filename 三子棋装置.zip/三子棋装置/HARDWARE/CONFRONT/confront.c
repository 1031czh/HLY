#include "confront.h"
#include "ti_msp_dl_config.h"
#include "uart.h"
#include "key.h"
#include "stepper_motor.h"
#include "oled.h"
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define CONFRONT_EMPTY          0
#define CONFRONT_BLACK          1
#define CONFRONT_WHITE          2

#define CONFRONT_BOARD_COUNT    9
#define CONFRONT_MAP_COUNT      9
#define CONFRONT_OUT_MARGIN_CM  4.0f
#define CONFRONT_WHITE_MAX_D2   (4.0f * 4.0f)
#define CONFRONT_SCORE_WIN      10
#define CONFRONT_SCORE_LOSE     (-10)
#define CONFRONT_SCORE_MIN      (-100)
#define CONFRONT_SCORE_MAX      100
#define CONFRONT_CORRECT_STABLE_FRAMES 2

typedef enum {
    CONFRONT_WAIT_MAP = 0,
    CONFRONT_FIRST_BLACK,   // Mode 1 AI (Black) start
    CONFRONT_WAIT_WHITE,    // Mode 1 Human (White)
    CONFRONT_BLACK_THINK,   // Mode 1 AI (Black)
    CONFRONT_BLACK_MOVE,    // Mode 1 AI (Black)
    CONFRONT_WAIT_BLACK,    // Mode 2 Human (Black) start
    CONFRONT_WHITE_THINK,   // Mode 2 AI (White)
    CONFRONT_WHITE_MOVE,    // Mode 2 AI (White)
    CONFRONT_CORRECT_MOVE,  // Mode 2 correction for displaced AI white piece
    CONFRONT_GAME_OVER
} ConfrontState_t;

static ConfrontState_t g_confront_state;
static uint8_t g_confront_board[CONFRONT_BOARD_COUNT];
static uint8_t g_confront_robot_owned[CONFRONT_BOARD_COUNT];
static uint8_t g_confront_last_white_count;
static uint8_t g_confront_last_black_count;
static int8_t g_confront_next_move;
static uint16_t g_confront_delay_cnt;
static int8_t g_confront_correct_src;
static int8_t g_confront_correct_dst;
static float g_confront_correct_pick_x;
static float g_confront_correct_pick_y;
static int8_t g_confront_last_correct_src;
static int8_t g_confront_last_correct_dst;
static uint8_t g_confront_correct_stable_count;
static uint8_t g_confront_correct_ignore_frames;
static uint8_t g_confront_stable_cnt;
static char g_confront_last_row2[32];

extern uint8_t motor_addr;
extern volatile uint8_t g_trigger_move;

static void Confront_ShowStatus(const char *status)
{
    char buf[32];
    sprintf(buf, "AI:%-13s", status);
    if (strcmp(g_confront_last_row2, buf) != 0)
    {
        strcpy(g_confront_last_row2, buf);
        OLED_ShowString(0, 2, (uint8_t *)buf, 16);
    }
}

static uint8_t Confront_IsPointInBoard(float x, float y)
{
    float min_x = 999.0f, max_x = -999.0f, min_y = 999.0f, max_y = -999.0f;

    if (g_map_rect_count < CONFRONT_MAP_COUNT) return 0;

    for (int i = 0; i < CONFRONT_MAP_COUNT; i++)
    {
        if (g_map_phys[i].x < min_x) min_x = g_map_phys[i].x;
        if (g_map_phys[i].x > max_x) max_x = g_map_phys[i].x;
        if (g_map_phys[i].y < min_y) min_y = g_map_phys[i].y;
        if (g_map_phys[i].y > max_y) max_y = g_map_phys[i].y;
    }

    min_x -= CONFRONT_OUT_MARGIN_CM;
    max_x += CONFRONT_OUT_MARGIN_CM;
    min_y -= CONFRONT_OUT_MARGIN_CM;
    max_y += CONFRONT_OUT_MARGIN_CM;

    return (x >= min_x && x <= max_x && y >= min_y && y <= max_y);
}

static uint8_t Confront_IsBetterSource(float x, float y, float best_x, float best_y)
{
    if (y < best_y - 0.1f) return 1;
    if (y > best_y + 0.1f) return 0;
    return (x < best_x);
}

static uint8_t Confront_FindBlackSource(float *x, float *y)
{
    uint8_t found = 0;
    float best_x = 999.0f, best_y = 999.0f;

    if (g_black_out_blob_count == 0 || g_map_rect_count < CONFRONT_MAP_COUNT) return 0;
    for (int i = 0; i < g_black_out_blob_count; i++)
    {
        float px = g_black_out_phys[i].x;
        float py = g_black_out_phys[i].y;
        if (Confront_IsPointInBoard(px, py)) continue;
        if (!found || Confront_IsBetterSource(px, py, best_x, best_y))
        {
            best_x = px;
            best_y = py;
            found = 1;
        }
    }
    if (found) { *x = best_x; *y = best_y; }
    return found;
}

static uint8_t Confront_FindWhiteSource(float *x, float *y)
{
    uint8_t found = 0;
    float best_x = 999.0f, best_y = 999.0f;

    if (g_white_out_blob_count == 0 || g_map_rect_count < CONFRONT_MAP_COUNT) return 0;
    for (int i = 0; i < g_white_out_blob_count; i++)
    {
        float px = g_white_out_phys[i].x;
        float py = g_white_out_phys[i].y;
        if (Confront_IsPointInBoard(px, py)) continue;
        if (!found || Confront_IsBetterSource(px, py, best_x, best_y))
        {
            best_x = px;
            best_y = py;
            found = 1;
        }
    }
    if (found) { *x = best_x; *y = best_y; }
    return found;
}

static uint8_t Confront_FindNearestCell(float x, float y, uint8_t *index)
{
    float best_d2 = CONFRONT_WHITE_MAX_D2;
    uint8_t found = 0;

    for (int i = 0; i < CONFRONT_BOARD_COUNT; i++)
    {
        float dx = x - g_map_phys[i].x;
        float dy = y - g_map_phys[i].y;
        float d2 = dx * dx + dy * dy;

        if (d2 <= best_d2)
        {
            best_d2 = d2;
            *index = (uint8_t)i;
            found = 1;
        }
    }
    return found;
}

static void Confront_BuildVisualOccupied(uint8_t occupied[CONFRONT_BOARD_COUNT])
{
    memset(occupied, 0, CONFRONT_BOARD_COUNT);

    if (g_map_rect_count < CONFRONT_MAP_COUNT) return;

    for (int i = 0; i < g_black_in_blob_count; i++)
    {
        uint8_t index;
        if (Confront_FindNearestCell(g_black_in_phys[i].x, g_black_in_phys[i].y, &index))
        {
            occupied[index] = 1;
        }
    }
    for (int i = 0; i < g_white_in_blob_count; i++)
    {
        uint8_t index;
        if (Confront_FindNearestCell(g_white_in_phys[i].x, g_white_in_phys[i].y, &index))
        {
            occupied[index] = 1;
        }
    }
}

static uint8_t Confront_IsCellVisuallyOccupied(uint8_t index)
{
    uint8_t occupied[CONFRONT_BOARD_COUNT];
    if (index >= CONFRONT_BOARD_COUNT) return 1;
    Confront_BuildVisualOccupied(occupied);
    return occupied[index];
}

static void Confront_SyncBoardFromVision(void)
{
    if (g_map_rect_count < CONFRONT_MAP_COUNT) return;

    for (int i = 0; i < g_black_in_blob_count; i++)
    {
        uint8_t index;
        if (Confront_FindNearestCell(g_black_in_phys[i].x, g_black_in_phys[i].y, &index) &&
            g_confront_board[index] == CONFRONT_EMPTY)
        {
            g_confront_board[index] = CONFRONT_BLACK;
        }
    }
    for (int i = 0; i < g_white_in_blob_count; i++)
    {
        uint8_t index;
        if (Confront_FindNearestCell(g_white_in_phys[i].x, g_white_in_phys[i].y, &index) &&
            g_confront_board[index] == CONFRONT_EMPTY)
        {
            g_confront_board[index] = CONFRONT_WHITE;
        }
    }
}

static void Confront_BuildObservedWhiteCells(uint8_t observed[CONFRONT_BOARD_COUNT],
                                             float pick_x[CONFRONT_BOARD_COUNT],
                                             float pick_y[CONFRONT_BOARD_COUNT])
{
    memset(observed, 0, CONFRONT_BOARD_COUNT);

    for (int i = 0; i < CONFRONT_BOARD_COUNT; i++)
    {
        pick_x[i] = 0.0f;
        pick_y[i] = 0.0f;
    }

    for (int i = 0; i < g_white_in_blob_count; i++)
    {
        uint8_t index;
        if (Confront_FindNearestCell(g_white_in_phys[i].x, g_white_in_phys[i].y, &index))
        {
            observed[index] = 1;
            pick_x[index] = g_white_in_phys[i].x;
            pick_y[index] = g_white_in_phys[i].y;
        }
    }
}

static void Confront_ClearCorrectCandidate(void)
{
    g_confront_correct_src = -1;
    g_confront_correct_dst = -1;
    g_confront_correct_pick_x = 0.0f;
    g_confront_correct_pick_y = 0.0f;
    g_confront_last_correct_src = -1;
    g_confront_last_correct_dst = -1;
    g_confront_correct_stable_count = 0;
}

static uint8_t Confront_DetectDisplacedRobotPiece(void)
{
    uint8_t observed[CONFRONT_BOARD_COUNT];
    float pick_x[CONFRONT_BOARD_COUNT];
    float pick_y[CONFRONT_BOARD_COUNT];
    int8_t missing_index = -1;
    int8_t extra_index = -1;
    uint8_t missing_count = 0;
    uint8_t extra_count = 0;
    uint8_t owned_count = 0;

    if (g_map_rect_count < CONFRONT_MAP_COUNT) return 0;

    Confront_BuildObservedWhiteCells(observed, pick_x, pick_y);

    for (int i = 0; i < CONFRONT_BOARD_COUNT; i++)
    {
        if (g_confront_robot_owned[i])
        {
            owned_count++;
            if (!observed[i])
            {
                missing_index = (int8_t)i;
                missing_count++;
            }
        }
        else if (observed[i])
        {
            extra_index = (int8_t)i;
            extra_count++;
        }
    }

    if (owned_count == 0 || missing_count != 1 || extra_count != 1)
    {
        Confront_ClearCorrectCandidate();
        return 0;
    }

    if (g_confront_board[missing_index] != CONFRONT_WHITE ||
        g_confront_board[extra_index] != CONFRONT_EMPTY)
    {
        Confront_ClearCorrectCandidate();
        return 0;
    }

    if (missing_index == g_confront_last_correct_src &&
        extra_index == g_confront_last_correct_dst)
    {
        if (g_confront_correct_stable_count < 255)
        {
            g_confront_correct_stable_count++;
        }
    }
    else
    {
        g_confront_last_correct_src = missing_index;
        g_confront_last_correct_dst = extra_index;
        g_confront_correct_stable_count = 1;
    }

    if (g_confront_correct_stable_count >= CONFRONT_CORRECT_STABLE_FRAMES)
    {
        g_confront_correct_src = missing_index;
        g_confront_correct_dst = extra_index;
        g_confront_correct_pick_x = pick_x[extra_index];
        g_confront_correct_pick_y = pick_y[extra_index];
        return 1;
    }

    return 0;
}

static uint8_t Confront_UpdateWhiteMove(void)
{
    for (int i = 0; i < g_white_in_blob_count; i++)
    {
        uint8_t index;
        if (Confront_FindNearestCell(g_white_in_phys[i].x, g_white_in_phys[i].y, &index) &&
            g_confront_board[index] == CONFRONT_EMPTY)
        {
            g_confront_board[index] = CONFRONT_WHITE;
            g_confront_last_white_count = g_white_in_blob_count;
            return 1;
        }
    }
    return 0;
}

static uint8_t Confront_UpdateBlackMove(void)
{
    for (int i = 0; i < g_black_in_blob_count; i++)
    {
        uint8_t index;
        if (Confront_FindNearestCell(g_black_in_phys[i].x, g_black_in_phys[i].y, &index) &&
            g_confront_board[index] == CONFRONT_EMPTY)
        {
            g_confront_board[index] = CONFRONT_BLACK;
            g_confront_last_black_count = g_black_in_blob_count;
            return 1;
        }
    }
    return 0;
}

static uint8_t Confront_CheckWinner(const uint8_t board[CONFRONT_BOARD_COUNT])
{
    static const uint8_t lines[8][3] = {
        {0, 1, 2}, {3, 4, 5}, {6, 7, 8},
        {0, 3, 6}, {1, 4, 7}, {2, 5, 8},
        {0, 4, 8}, {2, 4, 6}
    };

    for (int i = 0; i < 8; i++)
    {
        uint8_t a = lines[i][0];
        uint8_t b = lines[i][1];
        uint8_t c = lines[i][2];

        if (board[a] != CONFRONT_EMPTY && board[a] == board[b] && board[b] == board[c])
        {
            return board[a];
        }
    }
    return CONFRONT_EMPTY;
}

static uint8_t Confront_IsFull(const uint8_t board[CONFRONT_BOARD_COUNT])
{
    for (int i = 0; i < CONFRONT_BOARD_COUNT; i++)
    {
        if (board[i] == CONFRONT_EMPTY) return 0;
    }
    return 1;
}

static int Confront_Minimax(uint8_t board[CONFRONT_BOARD_COUNT], uint8_t is_black_turn, int alpha, int beta, uint8_t depth)
{
    static const uint8_t move_order[CONFRONT_BOARD_COUNT] = {4, 0, 2, 6, 8, 1, 3, 5, 7};
    uint8_t winner = Confront_CheckWinner(board);

    if (winner == CONFRONT_BLACK) return CONFRONT_SCORE_WIN - depth;
    if (winner == CONFRONT_WHITE) return CONFRONT_SCORE_LOSE + depth;
    if (Confront_IsFull(board)) return 0;

    if (is_black_turn)
    {
        int best = CONFRONT_SCORE_MIN;
        for (int i = 0; i < CONFRONT_BOARD_COUNT; i++)
        {
            uint8_t move = move_order[i];
            if (board[move] != CONFRONT_EMPTY) continue;

            board[move] = CONFRONT_BLACK;
            int score = Confront_Minimax(board, 0, alpha, beta, depth + 1);
            board[move] = CONFRONT_EMPTY;

            if (score > best) best = score;
            if (best > alpha) alpha = best;
            if (beta <= alpha) break;
        }
        return best;
    }
    else
    {
        int best = CONFRONT_SCORE_MAX;
        for (int i = 0; i < CONFRONT_BOARD_COUNT; i++)
        {
            uint8_t move = move_order[i];
            if (board[move] != CONFRONT_EMPTY) continue;

            board[move] = CONFRONT_WHITE;
            int score = Confront_Minimax(board, 1, alpha, beta, depth + 1);
            board[move] = CONFRONT_EMPTY;

            if (score < best) best = score;
            if (best < beta) beta = best;
            if (beta <= alpha) break;
        }
        return best;
    }
}

// Mode 1: AI is Black
static int8_t Confront_FindBestMoveBlack(void)
{
    static const uint8_t move_order[CONFRONT_BOARD_COUNT] = {4, 0, 2, 6, 8, 1, 3, 5, 7};
    int best_score = CONFRONT_SCORE_MIN;
    int8_t best_move = -1;

    for (int i = 0; i < CONFRONT_BOARD_COUNT; i++)
    {
        uint8_t move = move_order[i];
        if (g_confront_board[move] != CONFRONT_EMPTY) continue;

        g_confront_board[move] = CONFRONT_BLACK;
        int score = Confront_Minimax(g_confront_board, 0, CONFRONT_SCORE_MIN, CONFRONT_SCORE_MAX, 1);
        g_confront_board[move] = CONFRONT_EMPTY;

        if (score > best_score)
        {
            best_score = score;
            best_move = (int8_t)move;
        }
    }
    return best_move;
}

// Mode 2: AI is White
static int8_t Confront_FindBestMoveWhite(void)
{
    static const uint8_t move_order[CONFRONT_BOARD_COUNT] = {4, 0, 2, 6, 8, 1, 3, 5, 7};
    int best_score = CONFRONT_SCORE_MAX;
    int8_t best_move = -1;

    for (int i = 0; i < CONFRONT_BOARD_COUNT; i++)
    {
        uint8_t move = move_order[i];
        if (g_confront_board[move] != CONFRONT_EMPTY) continue;

        g_confront_board[move] = CONFRONT_WHITE;
        int score = Confront_Minimax(g_confront_board, 1, CONFRONT_SCORE_MIN, CONFRONT_SCORE_MAX, 1);
        g_confront_board[move] = CONFRONT_EMPTY;

        if (score < best_score)
        {
            best_score = score;
            best_move = (int8_t)move;
        }
    }
    return best_move;
}


static void Confront_SetGameOver(uint8_t winner)
{
    g_confront_state = CONFRONT_GAME_OVER;
    if (winner == CONFRONT_BLACK)
    {
        Confront_ShowStatus(g_current_mode == 1 ? "WIN" : "LOSE"); // Mode 1 AI=Black, Mode 2 AI=White
    }
    else if (winner == CONFRONT_WHITE)
    {
        Confront_ShowStatus(g_current_mode == 1 ? "LOSE" : "WIN");
    }
    else
    {
        Confront_ShowStatus("DRAW");
    }
}

void Confront_Reset(void)
{
    memset(g_confront_board, 0, sizeof(g_confront_board));
    memset(g_confront_robot_owned, 0, sizeof(g_confront_robot_owned));
    g_confront_state = CONFRONT_WAIT_MAP;
    g_confront_last_white_count = g_white_in_blob_count;
    g_confront_last_black_count = g_black_in_blob_count;
    g_confront_next_move = -1;
    g_confront_delay_cnt = 0;
    Confront_ClearCorrectCandidate();
    g_confront_correct_ignore_frames = 0;
    g_confront_stable_cnt = 0;
    g_confront_last_row2[0] = '\0';
}

void Confront_Init(void)
{
    Confront_Reset();
}

void Confront_Process(void)
{
    float source_x, source_y;
    uint8_t winner;
    char status[16];
    int8_t first_move;

    if (g_current_mode != 1 && g_current_mode != 2)
    {
        return;
    }

    switch (g_confront_state)
    {
        case CONFRONT_WAIT_MAP:
            if (g_map_rect_count < CONFRONT_MAP_COUNT)
            {
                Confront_ShowStatus("WAIT MAP");
            }
            else
            {
                Confront_ShowStatus("PRESS K2");
                if (g_trigger_move)
                {
                    g_trigger_move = 0; // 消耗触发标志
                    if (g_current_mode == 1) {
                        g_confront_last_white_count = g_white_in_blob_count;
                        g_confront_state = CONFRONT_FIRST_BLACK;
                    } else if (g_current_mode == 2) {
                        g_confront_last_black_count = g_black_in_blob_count;
                        g_confront_state = CONFRONT_WAIT_BLACK;
                    }
                }
            }
            break;

        // ==========================================
        // Mode 1: AI plays Black
        // ==========================================
        case CONFRONT_FIRST_BLACK:
            if (g_confront_delay_cnt == 0) Confront_ShowStatus("THINKING...");
            if (++g_confront_delay_cnt < 200) break;
            g_confront_delay_cnt = 0;

            Confront_SyncBoardFromVision();
            first_move = 0;
            if (g_confront_board[first_move] != CONFRONT_EMPTY || Confront_IsCellVisuallyOccupied((uint8_t)first_move))
            {
                first_move = Confront_FindBestMoveBlack();
            }

            if (first_move < 0)
            {
                Confront_SetGameOver(CONFRONT_EMPTY);
            }
            else if (Confront_FindBlackSource(&source_x, &source_y))
            {
                if (zdt_fivebar_pick_and_place(UART_Left_INST, UART_Right_INST, motor_addr,
                                               source_x, source_y,
                                               g_map_phys[first_move].x,
                                               g_map_phys[first_move].y))
                {
                    g_confront_board[first_move] = CONFRONT_BLACK;
                    g_confront_last_white_count = g_white_in_blob_count;
                    g_confront_state = CONFRONT_WAIT_WHITE;
                }
                else
                {
                    Confront_ShowStatus("MOVE ERR");
                }
            }
            else
            {
                Confront_ShowStatus("WAIT BLACK");
            }
            break;

        case CONFRONT_WAIT_WHITE:
            Confront_ShowStatus("WAIT W");
            if (g_white_in_blob_count < g_confront_last_white_count) g_confront_last_white_count = g_white_in_blob_count;
            if (g_white_in_data_ready && g_white_in_blob_count > g_confront_last_white_count)
            {
                if (Confront_UpdateWhiteMove())
                {
                    winner = Confront_CheckWinner(g_confront_board);
                    if (winner == CONFRONT_WHITE) Confront_SetGameOver(CONFRONT_WHITE);
                    else if (Confront_IsFull(g_confront_board)) Confront_SetGameOver(CONFRONT_EMPTY);
                    else g_confront_state = CONFRONT_BLACK_THINK;
                }
            }
            break;

        case CONFRONT_BLACK_THINK:
            if (g_confront_delay_cnt == 0) Confront_ShowStatus("THINKING...");
            if (++g_confront_delay_cnt < 200) break;
            g_confront_delay_cnt = 0;

            Confront_SyncBoardFromVision();
            g_confront_next_move = Confront_FindBestMoveBlack();
            if (g_confront_next_move < 0) Confront_SetGameOver(CONFRONT_EMPTY);
            else
            {
                sprintf(status, "MOVE %d", g_confront_next_move + 1);
                Confront_ShowStatus(status);
                g_confront_state = CONFRONT_BLACK_MOVE;
            }
            break;

        case CONFRONT_BLACK_MOVE:
            if (g_confront_next_move < 0 || g_confront_next_move >= CONFRONT_BOARD_COUNT)
            {
                Confront_SetGameOver(CONFRONT_EMPTY);
                break;
            }
            if (g_confront_board[g_confront_next_move] != CONFRONT_EMPTY ||
                Confront_IsCellVisuallyOccupied((uint8_t)g_confront_next_move))
            {
                g_confront_next_move = -1;
                g_confront_state = CONFRONT_BLACK_THINK;
                break;
            }
            if (Confront_FindBlackSource(&source_x, &source_y))
            {
                if (zdt_fivebar_pick_and_place(UART_Left_INST, UART_Right_INST, motor_addr,
                                               source_x, source_y,
                                               g_map_phys[g_confront_next_move].x,
                                               g_map_phys[g_confront_next_move].y))
                {
                    g_confront_board[g_confront_next_move] = CONFRONT_BLACK;
                    g_confront_next_move = -1;

                    winner = Confront_CheckWinner(g_confront_board);
                    if (winner == CONFRONT_BLACK) Confront_SetGameOver(CONFRONT_BLACK);
                    else if (Confront_IsFull(g_confront_board)) Confront_SetGameOver(CONFRONT_EMPTY);
                    else
                    {
                        g_confront_last_white_count = g_white_in_blob_count;
                        g_confront_state = CONFRONT_WAIT_WHITE;
                    }
                }
                else
                {
                    Confront_ShowStatus("MOVE ERR");
                }
            }
            else
            {
                Confront_ShowStatus("WAIT BLACK");
            }
            break;

        // ==========================================
        // Mode 2: AI plays White (Human plays Black)
        // ==========================================
        case CONFRONT_WAIT_BLACK:
            Confront_ShowStatus("WAIT B");
            if (g_confront_correct_ignore_frames > 0)
            {
                g_confront_correct_ignore_frames--;
            }
            else if (Confront_DetectDisplacedRobotPiece())
            {
                g_confront_state = CONFRONT_CORRECT_MOVE;
                break;
            }
            if (g_black_in_blob_count < g_confront_last_black_count) g_confront_last_black_count = g_black_in_blob_count;
            if (g_black_in_data_ready && g_black_in_blob_count > g_confront_last_black_count)
            {
                if (Confront_UpdateBlackMove())
                {
                    winner = Confront_CheckWinner(g_confront_board);
                    if (winner == CONFRONT_BLACK) Confront_SetGameOver(CONFRONT_BLACK);
                    else if (Confront_IsFull(g_confront_board)) Confront_SetGameOver(CONFRONT_EMPTY);
                    else g_confront_state = CONFRONT_WHITE_THINK;
                }
            }
            break;

        case CONFRONT_WHITE_THINK:
            if (g_confront_delay_cnt == 0) Confront_ShowStatus("THINKING...");
            if (++g_confront_delay_cnt < 200) break;
            g_confront_delay_cnt = 0;

            Confront_SyncBoardFromVision();
            g_confront_next_move = Confront_FindBestMoveWhite();
            if (g_confront_next_move < 0) Confront_SetGameOver(CONFRONT_EMPTY);
            else
            {
                sprintf(status, "MOVE %d", g_confront_next_move + 1);
                Confront_ShowStatus(status);
                g_confront_state = CONFRONT_WHITE_MOVE;
            }
            break;

        case CONFRONT_WHITE_MOVE:
            if (g_confront_next_move < 0 || g_confront_next_move >= CONFRONT_BOARD_COUNT)
            {
                Confront_SetGameOver(CONFRONT_EMPTY);
                break;
            }
            if (g_confront_board[g_confront_next_move] != CONFRONT_EMPTY ||
                Confront_IsCellVisuallyOccupied((uint8_t)g_confront_next_move))
            {
                g_confront_next_move = -1;
                g_confront_state = CONFRONT_WHITE_THINK;
                break;
            }
            if (Confront_FindWhiteSource(&source_x, &source_y))
            {
                if (zdt_fivebar_pick_and_place(UART_Left_INST, UART_Right_INST, motor_addr,
                                               source_x, source_y,
                                               g_map_phys[g_confront_next_move].x,
                                               g_map_phys[g_confront_next_move].y))
                {
                    g_confront_board[g_confront_next_move] = CONFRONT_WHITE;
                    g_confront_robot_owned[g_confront_next_move] = 1;
                    g_confront_next_move = -1;

                    winner = Confront_CheckWinner(g_confront_board);
                    if (winner == CONFRONT_WHITE) Confront_SetGameOver(CONFRONT_WHITE);
                    else if (Confront_IsFull(g_confront_board)) Confront_SetGameOver(CONFRONT_EMPTY);
                    else
                    {
                        g_confront_last_black_count = g_black_in_blob_count;
                        g_confront_state = CONFRONT_WAIT_BLACK;
                    }
                }
                else
                {
                    Confront_ShowStatus("MOVE ERR");
                }
            }
            else
            {
                Confront_ShowStatus("WAIT WHITE");
            }
            break;

        case CONFRONT_CORRECT_MOVE:
            Confront_ShowStatus("CORRECT");
            if (g_confront_correct_src >= 0 &&
                g_confront_correct_src < CONFRONT_BOARD_COUNT)
            {
                zdt_fivebar_pick_and_place(UART_Left_INST, UART_Right_INST, motor_addr,
                                           g_confront_correct_pick_x,
                                           g_confront_correct_pick_y,
                                           g_map_phys[g_confront_correct_src].x,
                                           g_map_phys[g_confront_correct_src].y);
            }
            Confront_ClearCorrectCandidate();
            g_confront_correct_ignore_frames = 2;
            g_confront_state = CONFRONT_WAIT_BLACK;
            break;

        case CONFRONT_GAME_OVER:
        default:
            break;
    }
}
