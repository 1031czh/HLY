#include "key.h"
#include "confront.h"
#include "ti_msp_dl_config.h"
#include "delay.h"
#include "oled.h"
#include "stepper_motor.h"
#include "uart.h"
#include <stdio.h>
#include "beef.h"

// ---- 长按阈值 (ms) ----
#define LONG_PRESS_THRESHOLD_MS  1000

// 全局按键状态计数变量
volatile uint32_t g_key_count = 0;
volatile uint8_t g_key_pressed_flag = 0;
volatile uint8_t g_selected_index = 0;  // 当前选中的地图点（0-based）

// 模式系统
volatile uint8_t g_current_mode = 0;         // 0=默认模式, 1=模式1, 2=模式2 ...
volatile uint8_t g_piece_color = 0;           // 0=黑子, 1=白子
volatile uint8_t g_piece_selected_index = 0;  // 当前选中的棋子索引
volatile uint8_t g_trigger_move = 0;           // 标记是否由按键2触发一键搬运逻辑

// 外部全局变量
extern uint8_t g_map_rect_count;
extern PhysPoint2D g_map_phys[];
extern uint8_t motor_addr;

// 黑白棋子外部变量
extern uint8_t g_black_out_blob_count;
extern PhysPoint2D g_black_out_phys[];
extern uint8_t g_white_out_blob_count;
extern PhysPoint2D g_white_out_phys[];


void Key_Init(void)
{
    // 采用读取电平轮询模式，不需要开启 NVIC 硬件中断
}

void Key_Process(void)
{
    // 实时读取三个引脚的电平状态（低电平0代表按下，高电平1代表松开）
    bool k1_pressed = (DL_GPIO_readPins(GPIOA, GPIO_Key_PIN_1_PIN) == 0);
    bool k2_pressed = (DL_GPIO_readPins(GPIOA, GPIO_Key_PIN_2_PIN) == 0);
    bool k3_pressed = (DL_GPIO_readPins(GPIOA, GPIO_Key_PIN_3_PIN) == 0);
    
    // 静态变量保存状态和计数器（在10ms的主循环节拍下递增）
    static uint32_t k1_hold_counter = 0;
    static bool k1_long_triggered = false;
    
    static uint32_t k3_hold_counter = 0;
    static bool k3_long_triggered = false;
    
    static bool last_k2 = false;

    // =============================================
    // 按键 1 (PA15)：短按=位置选择，长按=黑白子切换
    // =============================================
    if (k1_pressed)
    {
        k1_hold_counter++;
        if (k1_hold_counter >= (LONG_PRESS_THRESHOLD_MS / 10)) // 100 * 10ms = 1000ms
        {
            if (!k1_long_triggered)
            {
                k1_long_triggered = true;
                // ---- 长按按键1：切换黑白子 ----
                Beef_ON();
                g_piece_color = (g_piece_color == 0) ? 1 : 0;
                g_piece_selected_index = 0;
            }
        }
    }
    else
    {
        // 只有当按下时间大于 20ms（2个10ms节拍，起消抖作用）且未触发长按时，松开才算短按
        if (k1_hold_counter >= 2 && !k1_long_triggered)
        {
            // ---- 短按按键1：位置/棋子循环选择 ----
            Beef_ON();
            g_key_count++;
            
            if (g_current_mode == 0) {
                Key1_IRQHandler();
            }
        }
        k1_hold_counter = 0;
        k1_long_triggered = false;
    }

    // =============================================
    // 按键 2 (PA16)：确认 → 控制电机到达选中坐标
    // =============================================
    if (k2_pressed)
    {
        if (!last_k2)
        {
            // 边缘检测触发
            delay_ms(20); // 独立消抖
            if (DL_GPIO_readPins(GPIOA, GPIO_Key_PIN_2_PIN) == 0)
            {
                g_key_count++;
                
                if (g_current_mode == 0)
                {
                    // 只有当有相应颜色的棋子在视野中，且已校准地图点，按下按键2才触发一键搬运
                    if (g_map_rect_count > 0)
                    {
                        if ((g_piece_color == 0 && g_black_out_blob_count > 0) || 
                            (g_piece_color == 1 && g_white_out_blob_count > 0))
                        {
                            Beef_ON();
                            g_trigger_move = 1; // 触发一键搬运
                        }
                    }
                }
                else
                {
                    // 模式 1 和 2：按下按键 2 确认开始对弈
                    Beef_ON();
                    g_trigger_move = 1; 
                }
            }
            last_k2 = true;
        }
    }
    else
    {
        last_k2 = false;
    }

    // =============================================
    // 按键 3 (PA17)：短按=模式切换，长按=零点保存
    // =============================================
    if (k3_pressed)
    {
        k3_hold_counter++;
        if (k3_hold_counter >= (LONG_PRESS_THRESHOLD_MS / 10)) // 100 * 10ms = 1000ms
        {
            if (!k3_long_triggered)
            {
                k3_long_triggered = true;
                // ---- 长按按键3：零点保存（原功能）----
                Beef_ON();
                Key3_IRQHandler();
            }
        }
    }
    else
    {
        // 只有当按下时间大于 20ms（2个10ms节拍）且未触发长按时，松开才算短按
        if (k3_hold_counter >= 2 && !k3_long_triggered)
        {
            // ---- 短按按键3：模式0/1/2切换 ----
            char buf[32];
            Beef_ON();
            g_current_mode = (g_current_mode + 1) % 3;
            g_piece_selected_index = 0;
            g_trigger_move = 0;   // 清除触发标志
            g_goto_count = 0;     // 重置移动次数计数，防止继电器状态混乱
            Confront_Reset();

            sprintf(buf, "Mode:%d          ", g_current_mode);
            OLED_ShowString(0, 0, (uint8_t *)buf, 16);
            if (g_current_mode == 0)
            {
                OLED_ShowString(0, 2, (uint8_t *)"Pt:--/--        ", 16);
            }
            else
            {
                OLED_ShowString(0, 2, (uint8_t *)"AI:WAIT MAP     ", 16);
            }
        }
        k3_hold_counter = 0;
        k3_long_triggered = false;
    }
}


/*
 按键 1 (PA15)：模式0 - 循环选择地图标号
 每按一次，选中标号 +1，超过总数后回到 1
 */
void Key1_IRQHandler(void)
{
    if (g_map_rect_count == 0) return;
    g_selected_index = (g_selected_index + 1) % g_map_rect_count;
    char buf[32];
    sprintf(buf, "Pt:%d/%d        ", g_selected_index + 1, g_map_rect_count);
    OLED_ShowString(0, 2, (uint8_t *)buf, 16);
}


/*
 按键 2 (PA16)：模式0 - 确认选择，控制电机到达选中的地图坐标
 通过五连杆逆运动学计算电机角度并发送绝对位置命令
 */
void Key2_IRQHandler(void)
{
    if (g_map_rect_count == 0) return;

    float x = g_map_phys[g_selected_index].x;
    float y = g_map_phys[g_selected_index].y;

    // 五连杆逆运动学 → 电机运动
    zdt_fivebar_goto(UART_Left_INST, UART_Right_INST, motor_addr, x, y);
}


/*
 按键 3 (PA17)：长按 - 设零点
 将左右两个电机的当前位置设为零点，保存到驱动器 Flash
 */
void Key3_IRQHandler(void)
{
    zdt_motor_set_zero(UART_Left_INST, motor_addr);
    zdt_motor_set_zero(UART_Right_INST, motor_addr);
    OLED_ShowString(0, 2, (uint8_t *)"Zero Saved!  ", 16);
}
