#ifndef HARDWARE_KEY_KEY_H_
#define HARDWARE_KEY_KEY_H_

#include <stdint.h>
#include <stdbool.h>

// ---- 按键计数 ----
extern volatile uint32_t g_key_count;
extern volatile uint8_t g_key_pressed_flag;

// ---- 地图坐标选中标号（模式 0 用，0-based）----
extern volatile uint8_t g_selected_index;

// ---- 模式系统 ----
extern volatile uint8_t g_current_mode;         // 当前模式 (0=默认, 1=模式1, 2=模式2, ...)

// ---- 棋子选择 ----
extern volatile uint8_t g_piece_color;           // 0=黑子, 1=白子
extern volatile uint8_t g_piece_selected_index;  // 当前选中的棋子索引（0-based）
extern volatile uint8_t g_trigger_move;          // 标记是否触发一键搬运

void Key_Init(void);
void Key_Process(void);

void Key1_IRQHandler(void); // PA15 按键1
void Key2_IRQHandler(void); // PA16 按键2
void Key3_IRQHandler(void); // PA17 按键3

#endif /* HARDWARE_KEY_KEY_H_ */
