
#include "ti_msp_dl_config.h"

void servoInit(void);
void setServoAngle(int16_t angle);

