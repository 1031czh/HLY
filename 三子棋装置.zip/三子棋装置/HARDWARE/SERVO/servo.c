#include "ti_msp_dl_config.h"
#include "servo.h"

#define SERVO_MIN_PULSE    500   // 最左位置(0度)对应的比较值
#define SERVO_MAX_PULSE    2500  // 最右位置(180度)对应的比较值

void servoInit(void)
{
    // 启动TIMG12定时器
    DL_TimerG_startCounter(PWM_SERVO_INST);
}

void setServoAngle(int16_t angle) 
{
    int32_t pulse;

    // 限制角度范围在-180到0之间
    if (angle > 0)
        angle = 0;
    if (angle < -180)
        angle = -180;

    // 计算脉宽：0度对应最右抬起(500)，-180度对应最左放下(2500)
    // 采用 signed 乘除运算，防止负数强转 uint32 产生溢出
    pulse = (int32_t)SERVO_MIN_PULSE - (int32_t)angle * (int32_t)(SERVO_MAX_PULSE - SERVO_MIN_PULSE) / 180;

    // 设置TIMG12的CC0通道（PA10）输出比较值
    DL_TimerG_setCaptureCompareValue(PWM_SERVO_INST, (uint32_t)pulse, DL_TIMER_CC_0_INDEX);
}