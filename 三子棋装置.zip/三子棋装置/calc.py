u = [445, 327, 560, 446, 330, 562, 448, 333, 563]
v = [309, 309, 311, 219, 217, 220, 127, 126, 129]
X = [0.0, -3.2, 3.2, 0.0, -3.2, 3.2, 0.0, -3.2, 3.2]
Y = [28.0, 28.0, 28.0, 31.2, 31.2, 31.2, 34.4, 34.4, 34.4]

n = len(u)
su = sum(u)
sv = sum(v)
su2 = sum([x*x for x in u])
sv2 = sum([x*x for x in v])
suv = sum([x*y for x, y in zip(u, v)])

def det3x3(m):
    return (m[0][0]*(m[1][1]*m[2][2] - m[1][2]*m[2][1]) -
            m[0][1]*(m[1][0]*m[2][2] - m[1][2]*m[2][0]) +
            m[0][2]*(m[1][0]*m[2][1] - m[1][1]*m[2][0]))

def solve(target):
    st = sum(target)
    sut = sum([x*t for x, t in zip(u, target)])
    svt = sum([y*t for y, t in zip(v, target)])
    
    A = [
        [su2, suv, su],
        [suv, sv2, sv],
        [su,  sv,  n ]
    ]
    detA = det3x3(A)
    
    Aa = [[sut, suv, su], [svt, sv2, sv], [st, sv, n]]
    Ab = [[su2, sut, su], [suv, svt, sv], [su, st, n]]
    Ac = [[su2, suv, sut], [suv, sv2, svt], [su, sv, st]]
    
    a = det3x3(Aa) / detA
    b = det3x3(Ab) / detA
    c = det3x3(Ac) / detA
    return a, b, c

try:
    a, b, c = solve(X)
    d, e, f = solve(Y)
    print(f"X = {a:.8f} * px + {b:.8f} * py + {c:.8f}")
    print(f"Y = {d:.8f} * px + {e:.8f} * py + {f:.8f}")
except Exception as err:
    print(err)
