#ifndef _USART_H
#define _USART_H
#include "stdint.h"

void UART1_Init(void);
void USART1_IRQHandler(void);

extern volatile uint8_t signal_received;  // ����Ϊ�ⲿ����
extern volatile uint8_t parking_signal ;
extern volatile uint8_t reversing_signal ;
extern volatile int8_t steering_command ;
extern volatile uint8_t new_steering_data ;
//extern volatile uint8_t received_data[2];  // ���ڴ洢���2���ֽ�
//extern volatile uint8_t data_index = 0;    // ��ǰ�洢λ��
#endif


