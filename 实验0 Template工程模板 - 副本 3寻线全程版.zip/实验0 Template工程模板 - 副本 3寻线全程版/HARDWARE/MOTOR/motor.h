#ifndef _MOTOR_H
#define _MOTOR_H
#include "stdint.h"

void Motor_GPIO_Init(void);
void Motor1_Set(int16_t speed);
void Motor2_Set(int16_t speed);



#endif



