#include "stm32f4xx.h"
#include "stdlib.h"

// --------------------���õ��1��IN1/IN2 + EN1��--------------------
//------------------IN1--PB12
//------------------IN2--PB13
//------------------IN3--PB14
//------------------IN4--PB15

//-------------------��ʼ������������----------------------------------
void Motor_GPIO_Init(void) 
	{
    GPIO_InitTypeDef GPIO_InitStruct;

    // ����GPIOBʱ�ӣ�IN1-IN4��
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

    // ����PB12-PB15Ϊ�����IN1-IN4��
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_Init(GPIOB, &GPIO_InitStruct);
}

void Motor1_Set(int16_t speed) //����
	{
		speed = (speed > 1000) ? 1000 : ((speed < -1000) ? -1000 : speed);
    if (speed > 0) {
        GPIO_SetBits(GPIOB, GPIO_Pin_13);   // IN1=1
        GPIO_ResetBits(GPIOB, GPIO_Pin_12); // IN2=0
    } else if (speed < 0) {
        GPIO_ResetBits(GPIOB, GPIO_Pin_13); // IN1=0
        GPIO_SetBits(GPIOB, GPIO_Pin_12);   // IN2=1
    } else {
        GPIO_ResetBits(GPIOB, GPIO_Pin_13); // IN1=0
        GPIO_ResetBits(GPIOB, GPIO_Pin_12); // IN2=0
    }
    TIM_SetCompare1(TIM1, abs(speed));  // EN1 PWM
}

// ���õ��2��IN3/IN4 + EN2������
void Motor2_Set(int16_t speed) 
	{
		speed = (speed > 1000) ? 1000 : ((speed < -1000) ? -1000 : speed);
    if (speed > 0) {
        GPIO_SetBits(GPIOB, GPIO_Pin_14);   // IN3=1
        GPIO_ResetBits(GPIOB, GPIO_Pin_15); // IN4=0
    } else if (speed < 0) {
        GPIO_ResetBits(GPIOB, GPIO_Pin_14); // IN3=0
        GPIO_SetBits(GPIOB, GPIO_Pin_15);   // IN4=1
    } else {
        GPIO_ResetBits(GPIOB, GPIO_Pin_14); // IN3=0
        GPIO_ResetBits(GPIOB, GPIO_Pin_15); // IN4=0
    }
    TIM_SetCompare4(TIM1, abs(speed));  // EN2 PWM
}
	

