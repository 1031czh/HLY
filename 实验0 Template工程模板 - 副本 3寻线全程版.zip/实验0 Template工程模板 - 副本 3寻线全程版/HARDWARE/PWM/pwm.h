#ifndef _PWM_H
#define _PWM_H
#include "stdint.h"

void TIM1_PWM_Init(uint16_t prescaler, uint16_t period);

#endif


