#ifndef _SERVO_H
#define _SERVO_H
#include "stdint.h"

void SERVO_Init(void);
void Servo_SetAngle(int8_t angle);
void Servo_SetAngle(int8_t angle);
void Servo_SetSpeed(int8_t speed);
int8_t Servo_GetCurrentAngle(void);
void Servo_RotateToAngle(int8_t target_angle);
void Servo_RotateByAngle(int8_t angle_delta);
void Reversing_Procedure(void);
void Parking_Procedure(void);
#endif


