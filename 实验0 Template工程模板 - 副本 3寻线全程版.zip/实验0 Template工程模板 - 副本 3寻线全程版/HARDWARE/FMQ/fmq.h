#ifndef _FMQ_H
#define _FMQ_H
#include "stdint.h"

void Beep_Init(void);
void Beep_On(void);
void Beep_Off(void);
void Beep_Time(uint32_t ms);
#endif


