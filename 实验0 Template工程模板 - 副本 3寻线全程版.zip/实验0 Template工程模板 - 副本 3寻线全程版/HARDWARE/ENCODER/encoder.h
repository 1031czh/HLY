#ifndef _ENCODER_H
#define _ENCODER_H
#include "stdint.h"

void Encoder_Left_Init(void);
void Encoder_Right_Init(void);
void Encoder_ResetCount(void);
int16_t Encoder_GetCount(void);
#endif
